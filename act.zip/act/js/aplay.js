document.addEventListener('DOMContentLoaded', function() {
    // Select elements
    const navToggle = document.querySelector('.nav-toggle');
    const navPanel = document.querySelector('.nav-panel');
    const content = document.querySelector('.content');

    // Check if elements exist before adding event listeners
    if (navToggle && navPanel && content) {
        console.log('Elements found, adding event listener'); // Debug log
        // Toggle navigation panel and update hamburger icon with synchronized animation
        navToggle.addEventListener('click', function() {
            console.log('Toggle clicked'); // Debug log
            const isActive = navPanel.classList.toggle('active');
            content.classList.toggle('shifted');
            navToggle.classList.toggle('active'); // Toggle hamburger to 'X'

            // Synchronize animation by forcing reflow
            content.style.transition = 'none';
            content.offsetHeight; // Trigger reflow
            content.style.transition = 'margin-left 0.5s ease-in-out, width 0.5s ease-in-out';
        });

        // Auto-show navigation on desktop
        function handleResize() {
            if (window.innerWidth > 768) {
                navPanel.classList.add('active');
                content.classList.add('shifted');
                content.style.width = 'calc(100% - 250px)';
                navToggle.classList.remove('active'); // Reset hamburger on desktop
            } else if (!navPanel.classList.contains('active')) {
                content.classList.remove('shifted');
                content.style.width = '100%';
            }
        }

        // Initial check on page load
        handleResize();

        // Handle window resize
        window.addEventListener('resize', handleResize);
    } else {
        console.warn('Required elements (.nav-toggle, .nav-panel, .content) not found.');
    }
});