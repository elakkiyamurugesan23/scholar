document.addEventListener("DOMContentLoaded", function () {
    // Sidebar Toggle
    const menuToggle = document.querySelector(".menu-toggle");
    const sidebar = document.querySelector(".sidebar");
    const mainContent = document.querySelector(".main-content");

    menuToggle.addEventListener("click", function () {
        sidebar.classList.toggle("collapsed");
        if (sidebar.classList.contains("collapsed")) {
            sidebar.style.width = "80px";
            mainContent.style.marginLeft = "80px";
        } else {
            sidebar.style.width = "250px";
            mainContent.style.marginLeft = "250px";
        }
    });

    // Real-Time Clock
    function updateClock() {
        const now = new Date();
        document.getElementById("datetime").textContent = now.toLocaleString();
    }
    setInterval(updateClock, 1000);
    updateClock();
});
document.addEventListener("DOMContentLoaded", function () {
    function updateClock() {
        const now = new Date();
        document.getElementById("datetime").textContent = now.toLocaleString();
    }
    setInterval(updateClock, 1000);
    updateClock();
});
function toggleSidebar() {
    let sidebar = document.getElementById("sidebar");
    let content = document.getElementById("content");

    sidebar.classList.toggle("open");
    content.classList.toggle("shifted");
}

