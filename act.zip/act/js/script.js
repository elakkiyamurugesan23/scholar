function toggleMenu() {
    let sidebar = document.querySelector(".sidebar");
    sidebar.classList.toggle("active");
}
