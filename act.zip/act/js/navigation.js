document.addEventListener("DOMContentLoaded", function() {
    const menuBtn = document.querySelector(".menu-btn");
    const sidebar = document.querySelector(".sidebar");
    const content = document.querySelector(".content");

    // Function to toggle sidebar
    function toggleSidebar() {
        sidebar.classList.toggle("collapsed");
        content.classList.toggle("shifted");

        // Save sidebar state in localStorage
        localStorage.setItem("sidebarCollapsed", sidebar.classList.contains("collapsed"));
    }

   menuBtn.addEventListener("click", function() {
        sidebar.classList.toggle("collapsed");
        if (sidebar.classList.contains("collapsed")) {
            content.style.marginLeft = "0px"; // Shift content when sidebar is closed
        } else {
            content.style.marginLeft = "220px"; // Reset content margin when sidebar opens
        }
    });
});