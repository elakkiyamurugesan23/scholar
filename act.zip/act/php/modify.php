<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

$conn = new mysqli("localhost", "root", "", "act");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$register_number = isset($_GET['id']) ? $_GET['id'] : "";
$student = [];

if (!empty($register_number)) {
    $stmt = $conn->prepare("SELECT * FROM students WHERE register_number = ?");
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("s", $register_number);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();
    $stmt->close();
}

if (!$student) {
    die("Student not found.");
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Modify Student</title>
    <link rel="stylesheet" href="../css/modify_style.css">
</head>
<body>

<div class="container">
    <h2>Modify Student Details</h2>

    <form action="update_student.php" method="post">
        <input type="hidden" name="register_number" value="<?php echo htmlspecialchars($student['register_number']); ?>">

        <label>Course:</label>
        <input type="text" name="Course" value="<?php echo htmlspecialchars($student['Course']); ?>" required>

        <label>Department:</label>
        <input type="text" name="department" value="<?php echo htmlspecialchars($student['department']); ?>" required>

        <label>Student Name:</label>
        <input type="text" name="Name_of_the_Student" value="<?php echo htmlspecialchars($student['Name_of_the_Student']); ?>" required>

        <label>Date of Birth:</label>
        <input type="date" name="date_of_birth" value="<?php echo htmlspecialchars($student['date_of_birth']); ?>" required>

        <label>Gender:</label>
        <select name="Gender" required>
            <option value="">Select Gender</option>
            <option value="Male" <?php if ($student['Gender'] === 'Male') echo 'selected'; ?>>Male</option>
            <option value="Female" <?php if ($student['Gender'] === 'Female') echo 'selected'; ?>>Female</option>
            <option value="Other" <?php if ($student['Gender'] === 'Other') echo 'selected'; ?>>Other</option>
        </select>

        <label>Community:</label>
        <input type="text" name="Community" value="<?php echo htmlspecialchars($student['Community']); ?>" required>

        <label>Religion:</label>
        <input type="text" name="Religion" value="<?php echo htmlspecialchars($student['Religion']); ?>" required>

        <label>Father Name:</label>
        <input type="text" name="father_name" value="<?php echo htmlspecialchars($student['father_name']); ?>" required>

        <label>Mother Name:</label>
        <input type="text" name="mother_name" value="<?php echo htmlspecialchars($student['mother_name']); ?>" required>

        <label>Address:</label>
        <textarea name="Address" required><?php echo htmlspecialchars($student['Address']); ?></textarea>

        <label>Blood Group:</label>
        <input type="text" name="Blood_Group" value="<?php echo htmlspecialchars($student['Blood_Group']); ?>" required>

        <label>Contact Number:</label>
        <input type="text" name="Contact_No" value="<?php echo htmlspecialchars($student['Contact_No']); ?>" required>

        <label>Email:</label>
        <input type="email" name="E_Mail" value="<?php echo htmlspecialchars($student['E_Mail']); ?>" required>

        <label>Aadhar Number:</label>
        <input type="text" name="Aadhar_No" value="<?php echo htmlspecialchars($student['Aadhar_No']); ?>" required>

        <label>PAN Number:</label>
        <input type="text" name="PAN_No" value="<?php echo htmlspecialchars($student['PAN_No']); ?>">

        <label>Bank Name:</label>
        <input type="text" name="Bank_Name" value="<?php echo htmlspecialchars($student['Bank_Name']); ?>">

        <label>Branch:</label>
        <input type="text" name="Branch" value="<?php echo htmlspecialchars($student['Branch']); ?>">

        <label>Account Number:</label>
        <input type="text" name="Account_No" value="<?php echo htmlspecialchars($student['Account_No']); ?>">

        <label>IFSC Code:</label>
        <input type="text" name="IFSC_Code" value="<?php echo htmlspecialchars($student['IFSC_Code']); ?>">

        <label>MICR Code:</label>
        <input type="text" name="MICR_Code" value="<?php echo htmlspecialchars($student['MICR_Code']); ?>">

        <label>Father Qualification:</label>
        <input type="text" name="Father_Qualification" value="<?php echo htmlspecialchars($student['Father_Qualification']); ?>" required>

        <label>Father Occupation:</label>
        <input type="text" name="Father_Occupation" value="<?php echo htmlspecialchars($student['Father_Occupation']); ?>" required>

        <label>Father Annual Income:</label>
        <input type="number" name="Father_Annual_Income" value="<?php echo htmlspecialchars($student['Father_Annual_Income']); ?>" required>

        <label>Mother Qualification:</label>
        <input type="text" name="Mother_Qualification" value="<?php echo htmlspecialchars($student['Mother_Qualification']); ?>" required>

        <label>Mother Occupation:</label>
        <input type="text" name="Mother_Occupation" value="<?php echo htmlspecialchars($student['Mother_Occupation']); ?>" required>

        <label>UMIS Number:</label>
        <input type="text" name="UMIS_NUMBER" value="<?php echo htmlspecialchars($student['UMIS_NUMBER']); ?>" required>

        <label>Identification Mark 1:</label>
        <input type="text" name="Identification_Mark1" value="<?php echo htmlspecialchars($student['Identification_Mark1']); ?>" required>

        <label>Identification Mark 2:</label>
        <input type="text" name="Identification_Mark2" value="<?php echo htmlspecialchars($student['Identification_Mark2']); ?>" required>

        <button type="submit" class="btn">Update</button>
    </form>
</div>

</body>
</html>