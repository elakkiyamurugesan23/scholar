<?php
session_start();
date_default_timezone_set("Asia/Kolkata");
$currentDateTime = date("Y-m-d H:i:s");

include 'db_connect.php'; // Include database connection

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$query = "SELECT * FROM scholarship_schemes";
$result = mysqli_query($conn, $query);

$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Guest'; // Default to 'Guest' if not set
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Schemes</title>
    <link rel="stylesheet" href="../css/approved_scholarships.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> <!-- Font Awesome for icons -->
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const menuBtn = document.querySelector(".menu-btn");
            const sidebar = document.querySelector(".sidebar");
            const content = document.querySelector(".content");

            // Function to toggle sidebar
            function toggleSidebar() {
                sidebar.classList.toggle("collapsed");
                content.classList.toggle("shifted");

                // Save sidebar state in localStorage
                localStorage.setItem("sidebarCollapsed", sidebar.classList.contains("collapsed"));
            }

            menuBtn.addEventListener("click", function() {
                toggleSidebar();
                if (sidebar.classList.contains("collapsed")) {
                    content.style.marginLeft = "0px"; // Shift content when sidebar is closed
                } else {
                    content.style.marginLeft = "220px"; // Reset content margin when sidebar opens
                }
            });

            // Load saved sidebar state
            const isCollapsed = localStorage.getItem("sidebarCollapsed") === "true";
            if (isCollapsed) {
                sidebar.classList.add("collapsed");
                content.classList.add("shifted");
                content.style.marginLeft = "0px";
            }
        });
    </script>
</head>
<body>
    <!-- Top Ribbon -->
    <div class="top-ribbon">
        <div class="ribbon-left">
            <button class="menu-btn" aria-label="Toggle Menu"><i class="fas fa-bars"></i></button>
            <h2>STUDENT SCHOLARSHIP PORTAL</h2>
        </div>
        <div class="ribbon-right">
            <span>Welcome, <?php echo htmlspecialchars($username); ?>!</span>
            <span><?php echo $currentDateTime; ?></span>
            <div class="dropdown">
                <button class="dropbtn" aria-label="User Menu"><i class="fas fa-user"></i></button>
                <div class="dropdown-content">
                    <a href="profile.php">Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Sidebar Navigation -->
    <div class="sidebar">
    <ul>
        <li><a href="dashboard_student.php">Dashboard</a></li>
        <li><a href="schemes_stu.php">Scholarship Schemes</a></li>
        <li><a href="applied_students_stu.php">Applied Students</a></li>
        <li><a href="app_stu.php">Approved Students</a></li>
        <li><a href="rejected_students_stu.php">Rejected Students</a></li>
        
        </ul>
    </div>

    <!-- Main Content -->
    <div class="content">
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Scheme Name</th>
                        <th>Applicable Income</th>
                        <th>Applicable Caste</th>
                        <th>Applicable Gender</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                        <tr>
                            <td><?= htmlspecialchars($row['scheme_name']); ?></td>
                            <td><?= htmlspecialchars($row['applicable_income']); ?></td>
                            <td><?= htmlspecialchars($row['applicable_caste']); ?></td>
                            <td><?= htmlspecialchars($row['applicable_gender']); ?></td>
                            <td><a href="apply_scholarship_stu.php?scheme_id=<?= $row['id']; ?>" class="apply-btn">Apply</a></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>