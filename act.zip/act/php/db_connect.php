<?php
$host = "localhost";
$username = "root";  // Change if using different MySQL user
$password = "";      // Change if using a password
$database = "act"; 

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
