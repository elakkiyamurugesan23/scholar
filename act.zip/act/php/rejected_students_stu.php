<?php
session_start(); // Start the session
include 'db_connect.php'; // Your database connection file (ensure $conn is set)

// Check if user is logged in
if (!isset($_SESSION['username']) || !isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'student') {
    // Redirect to login if not logged in or not a student
    header("Location: login.php");
    exit();
}

// Fetch register_number using username from users table
$username = mysqli_real_escape_string($conn, $_SESSION['username']);
$sql_user = "SELECT register_number FROM users WHERE username = '$username'";
$result_user = mysqli_query($conn, $sql_user);

$register_number = null;
if ($result_user && mysqli_num_rows($result_user) > 0) {
    $user = mysqli_fetch_assoc($result_user);
    $register_number = $user['register_number'];
}

if (!$register_number) {
    // If register_number couldn't be fetched, redirect to login
    echo "No register_number found for username: " . htmlspecialchars($username) . ". Redirecting to login...\n";
    header("Location: login.php");
    exit();
}

// Fetch rejected students for the logged-in user
$sql = "SELECT Name_of_the_Student, register_number, department, Course, scheme_name, status 
        FROM rejected 
        WHERE register_number = '$register_number' 
        ORDER BY application_date DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Rejected Students</title>
  <link rel="stylesheet" href="../css/dashboard_style.css">
  <link rel="stylesheet" href="../css/rejected_students.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>
  <!-- Top Ribbon -->
  <div class="top-ribbon">
    <div class="ribbon-left">
      <button class="menu-btn" onclick="toggleSidebar()">☰</button>
      STUDENT SCHOLARSHIP PORTAL
    </div>
    <div class="ribbon-right">
      <span>Welcome, <?php echo $_SESSION['username']; ?></span>
      <div class="dropdown">
        <button class="dropbtn">☰</button>
        <div class="dropdown-content">
          <a href="profile.php">Profile</a>
          <a href="logout.php">Logout</a>
        </div>
      </div>
    </div>
  </div>
  
  <!-- Sidebar Navigation -->
  <div class="sidebar" id="sidebar">
  <ul>
        <li><a href="dashboard_student.php">Dashboard</a></li>
        <li><a href="schemes_stu.php">Scholarship Schemes</a></li>
        <li><a href="applied_students_stu.php">Applied Students</a></li>
        <li><a href="app_stu.php">Approved Students</a></li>
        <li><a href="rejected_students_stu.php">Rejected Students</a></li>
        
        </ul>
  </div>
  
  <!-- Main Content -->
  <div class="content">
    <h2 class="title">Rejected Students</h2>

    <!-- Rejected Students Table -->
    <div class="table-container">
      <!-- Add Download Report Button -->
      <div style="margin-bottom: 20px; text-align: right;">
        <a href="download_rejected_report_stu.php" class="cool-report-btn"><i class="fa fa-download"></i> Download Report</a>
      </div>
      <table class="styled-table">
        <thead>
          <tr>
            <th>REGISTER NUMBER</th>
            <th>STUDENT NAME</th>
            <th>DEPARTMENT</th>
            <th>COURSE</th>
            <th>SCHEME NAME</th>
            <th>STATUS</th>
          </tr>
        </thead>
        <tbody>
          <?php
          if ($register_number && mysqli_num_rows($result) > 0) {
              while ($row = mysqli_fetch_assoc($result)) {
                  echo "<tr>"
                      . "<td>" . htmlspecialchars($row['register_number']) . "</td>"
                      . "<td>" . htmlspecialchars($row['Name_of_the_Student']) . "</td>"
                      . "<td>" . htmlspecialchars($row['department'] ?? 'N/A') . "</td>"
                      . "<td>" . htmlspecialchars($row['Course'] ?? 'N/A') . "</td>"
                      . "<td>" . htmlspecialchars($row['scheme_name']) . "</td>"
                      . "<td>" . htmlspecialchars($row['status']) . "</td>"
                      . "</tr>";
              }
          } else {
              echo "<tr><td colspan='6' style='text-align: center;'>No rejected forms found for you.</td></tr>";
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>
  
  <script>
    function toggleSidebar() {
      let sidebar = document.getElementById("sidebar");
      sidebar.classList.toggle("active");
    }
  </script>
</body>
</html>