<?php
include 'db_connect.php'; // Your database connection file

// Get action and ID from URL
$action = isset($_GET['action']) ? $_GET['action'] : '';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id == 0 || !in_array($action, ['approve', 'reject'])) {
    die("Invalid request.");
}

// Fetch application details
$sql_app = "SELECT * FROM scholarship_applications WHERE id = $id";
$result_app = mysqli_query($conn, $sql_app);
$application = mysqli_fetch_assoc($result_app);

if (!$application) {
    die("Application not found.");
}

// Fetch student details
$register_number = $application['register_number'];
$sql_student = "SELECT * FROM students WHERE register_number = '$register_number'";
$result_student = mysqli_query($conn, $sql_student);
$student = mysqli_fetch_assoc($result_student);

// Fetch scheme details
$scheme_name = $application['scheme_name'];
$sql_scheme = "SELECT * FROM scholarship_schemes WHERE scheme_name = '$scheme_name'";
$result_scheme = mysqli_query($conn, $sql_scheme);
$scheme = mysqli_fetch_assoc($result_scheme);

// Prepare data for insertion (aligned with approve_page.php)
$data = [
    'register_number' => $student['register_number'],
    'Name_of_the_Student' => $student['Name_of_the_Student'],
    'Gender' => $student['Gender'] ?? null,
    'date_of_birth' => $student['date_of_birth'] ?? null,
    'Course' => $student['Course'] ?? null,
    'department' => $student['department'] ?? null,
    'Community' => $student['Community'] ?? null,
    'Religion' => $student['Religion'] ?? null,
    'Contact_No' => $student['Contact_No'] ?? null,
    'UMIS_NUMBER' => $student['UMIS_NUMBER'] ?? null,
    'Aadhar_No' => $student['Aadhar_No'] ?? null,
    'Address' => $student['Address'] ?? null,
    'father_name' => $student['father_name'] ?? null,
    'mother_name' => $student['mother_name'] ?? null,
    'Father_Occupation' => $student['Father_Occupation'] ?? null,
    'Mother_Occupation' => $student['Mother_Occupation'] ?? null,
    'Father_Annual_Income' => $student['Father_Annual_Income'] ?? null,
    'Blood_Group' => $student['Blood_Group'] ?? null,
    'E_Mail' => $student['E_Mail'] ?? null,
    'PAN_No' => $student['PAN_No'] ?? null,
    'Bank_Name' => $student['Bank_Name'] ?? null,
    'Branch' => $student['Branch'] ?? null,
    'Account_No' => $student['Account_No'] ?? null,
    'IFSC_Code' => $student['IFSC_Code'] ?? null,
    'MICR_Code' => $student['MICR_Code'] ?? null,
    'Father_Qualification' => $student['Father_Qualification'] ?? null,
    'Mother_Qualification' => $student['Mother_Qualification'] ?? null,
    'Identification_Mark1' => $student['Identification_Mark1'] ?? null,
    'Identification_Mark2' => $student['Identification_Mark2'] ?? null,
    'scheme_name' => $scheme['scheme_name'],
    'applicable_income' => $scheme['applicable_income'] ?? null,
    'applicable_caste' => $scheme['applicable_caste'] ?? null,
    'applicable_gender' => $scheme['applicable_gender'] ?? null,
    'application_date' => $application['application_date']
];

// Determine the target table and status
if ($action === 'approve') {
    $table = 'approved';
    $status = 'Approved';
} else {
    $table = 'rejected';
    $status = 'Rejected';
}

// Use prepared statements to insert data into the appropriate table
$sql = "INSERT INTO $table (
    register_number, Name_of_the_Student, Gender, date_of_birth, Course, department, Community,
    Religion, Contact_No, UMIS_NUMBER, Aadhar_No, Address, father_name, mother_name,
    Father_Occupation, Mother_Occupation, Father_Annual_Income, Blood_Group, E_Mail,
    PAN_No, Bank_Name, Branch, Account_No, IFSC_Code, MICR_Code, Father_Qualification,
    Mother_Qualification, Identification_Mark1, Identification_Mark2, scheme_name,
    applicable_income, applicable_caste, applicable_gender, application_date, status
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "sssssssssssssssssssssssssssssssssss",
    $data['register_number'],
    $data['Name_of_the_Student'],
    $data['Gender'],
    $data['date_of_birth'],
    $data['Course'],
    $data['department'],
    $data['Community'],
    $data['Religion'],
    $data['Contact_No'],
    $data['UMIS_NUMBER'],
    $data['Aadhar_No'],
    $data['Address'],
    $data['father_name'],
    $data['mother_name'],
    $data['Father_Occupation'],
    $data['Mother_Occupation'],
    $data['Father_Annual_Income'],
    $data['Blood_Group'],
    $data['E_Mail'],
    $data['PAN_No'],
    $data['Bank_Name'],
    $data['Branch'],
    $data['Account_No'],
    $data['IFSC_Code'],
    $data['MICR_Code'],
    $data['Father_Qualification'],
    $data['Mother_Qualification'],
    $data['Identification_Mark1'],
    $data['Identification_Mark2'],
    $data['scheme_name'],
    $data['applicable_income'],
    $data['applicable_caste'],
    $data['applicable_gender'],
    $data['application_date'],
    $status
);

if ($stmt->execute()) {
    // Delete from scholarship_applications (for both approve and reject)
    $delete_sql = "DELETE FROM scholarship_applications WHERE id = ?";
    $delete_stmt = $conn->prepare($delete_sql);
    $delete_stmt->bind_param("i", $id);
    if ($delete_stmt->execute()) {
        // Redirect with success message
        header("Location: applied_students.php?message=" . urlencode("Application $status successfully"));
    } else {
        // Redirect with error message if deletion fails
        header("Location: applied_students.php?message=" . urlencode("Error deleting application from scholarship_applications"));
    }
    $delete_stmt->close();
} else {
    // Redirect with error message if insertion fails
    header("Location: applied_students.php?message=" . urlencode("Error processing application"));
}

$stmt->close();
$conn->close();
exit();
?>