<?php
// Start session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
include 'db_connect.php';

// Fetch course details from the database
$sql = "SELECT register_number, student_name, scheme_id, scheme_name FROM course_details";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Details</title>
    <link rel="stylesheet" href="course_details.css">
    <script src="script.js"></script>
</head>
<body>

<!-- Include Top Ribbon -->
<?php include 'coursetop_ribbon.php'; ?>

<div class="container">
    <h2>Course Details</h2>
    <table border="1">
        <thead>
            <tr>
                <th>Register Number</th>
                <th>Student Name</th>
                <th>Scheme ID</th>
                <th>Scheme Name</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['register_number']}</td>
                            <td>{$row['student_name']}</td>
                            <td>{$row['scheme_id']}</td>
                            <td>{$row['scheme_name']}</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='4'>No records found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>


   
