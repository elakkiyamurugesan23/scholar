<?php
include("db_connect.php");

$admin_pass = password_hash("adminpass", PASSWORD_BCRYPT);
$student_pass = password_hash("studentpass", PASSWORD_BCRYPT);

$sql = "INSERT INTO users (name, username, email, phone_number, password, user_type) VALUES 
('Admin User', 'admin123', 'admin@example.com', '9876543210', '$admin_pass', 'admin'),
('Student User', 'student123', 'student@example.com', '9876543211', '$student_pass', 'student')";

if ($conn->query($sql) === TRUE) {
    echo "Users inserted successfully.";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
