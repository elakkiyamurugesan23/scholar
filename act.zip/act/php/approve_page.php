<?php
include 'db_connect.php'; // Your database connection file

// Get the application ID from URL
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch application details
$sql_app = "SELECT * FROM scholarship_applications WHERE id = $id";
$result_app = mysqli_query($conn, $sql_app);
$application = mysqli_fetch_assoc($result_app);

if (!$application) {
    die("Application not found.");
}

// Fetch student details
$register_number = $application['register_number'];
$sql_student = "SELECT * FROM students WHERE register_number = '$register_number'";
$result_student = mysqli_query($conn, $sql_student);
$student = mysqli_fetch_assoc($result_student);

// Fetch scheme details
$scheme_name = $application['scheme_name'];
$sql_scheme = "SELECT * FROM scholarship_schemes WHERE scheme_name = '$scheme_name'";
$result_scheme = mysqli_query($conn, $sql_scheme);
$scheme = mysqli_fetch_assoc($result_scheme);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Details</title>
    <link rel="stylesheet" href="../css/dashboard_style.css">
    <link rel="stylesheet" href="../css/approve_page.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>
    <!-- Top Ribbon -->
    <div class="top-ribbon">
        <div class="ribbon-left">
            <button class="menu-btn" onclick="toggleSidebar()">☰</button>
            STUDENT SCHOLARSHIP PORTAL
        </div>
        <div class="ribbon-right">
            <span>Welcome, Admin</span>
            <div class="dropdown">
                <button class="dropbtn">▼</button>
                <div class="dropdown-content">
                    <a href="#">Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
      <li><a href="student_info.php">Student Information</a></li>
      <li><a href="schemes.php">Scholarship Schemes</a></li>
      <li><a href="applied_students.php">Applied Students</a></li>
      <li><a href="app.php">Approved Students</a></li>
      <li><a href="rejected_students.php">Rejected Students</a></li>

        </ul>
    </div>

    <!-- Main Content -->
    <div class="content">
        <h2 class="title">Application Details</h2>
        
        <!-- Student Details Section -->
        <div class="details-section">
            <h3>Student Details</h3>
            <div class="details-grid">
            <div class="detail-item"><strong>Student Name:</strong> <?php echo htmlspecialchars($student['Name_of_the_Student']); ?></div>
<div class="detail-item"><strong>Register Number:</strong> <?php echo htmlspecialchars($student['register_number']); ?></div>
<div class="detail-item"><strong>Gender:</strong> <?php echo htmlspecialchars($student['Gender']); ?></div>
<div class="detail-item"><strong>Date of Birth:</strong> <?php echo htmlspecialchars($student['date_of_birth']); ?></div>
<div class="detail-item"><strong>Course:</strong> <?php echo htmlspecialchars($student['Course']); ?></div>
<div class="detail-item"><strong>Department:</strong> <?php echo htmlspecialchars($student['department']); ?></div>
<div class="detail-item"><strong>Community:</strong> <?php echo htmlspecialchars($student['Community']); ?></div>
<div class="detail-item"><strong>Religion:</strong> <?php echo htmlspecialchars($student['Religion']); ?></div>
<div class="detail-item"><strong>Phone Number:</strong> <?php echo htmlspecialchars($student['Contact_No']); ?></div>
<div class="detail-item"><strong>UMIS Number:</strong> <?php echo htmlspecialchars($student['UMIS_NUMBER']); ?></div>
<div class="detail-item"><strong>Aadhar Number:</strong> <?php echo htmlspecialchars($student['Aadhar_No']); ?></div>
<div class="detail-item"><strong>Address:</strong> <?php echo htmlspecialchars($student['Address']); ?></div>
<div class="detail-item"><strong>Father Name:</strong> <?php echo htmlspecialchars($student['father_name']); ?></div>
<div class="detail-item"><strong>Mother Name:</strong> <?php echo htmlspecialchars($student['mother_name']); ?></div>
<div class="detail-item"><strong>Father Occupation:</strong> <?php echo htmlspecialchars($student['Father_Occupation']); ?></div>
<div class="detail-item"><strong>Mother Occupation:</strong> <?php echo htmlspecialchars($student['Mother_Occupation']); ?></div>
<div class="detail-item"><strong>Annual Family Income:</strong> <?php echo htmlspecialchars($student['Father_Annual_Income']); ?></div>
<div class="detail-item"><strong>Blood Group:</strong> <?php echo htmlspecialchars($student['Blood_Group']); ?></div>
<div class="detail-item"><strong>Email:</strong> <?php echo htmlspecialchars($student['E_Mail']); ?></div>
<div class="detail-item"><strong>PAN Number:</strong> <?php echo htmlspecialchars($student['PAN_No']); ?></div>
<div class="detail-item"><strong>Bank Name:</strong> <?php echo htmlspecialchars($student['Bank_Name']); ?></div>
<div class="detail-item"><strong>Branch:</strong> <?php echo htmlspecialchars($student['Branch']); ?></div>
<div class="detail-item"><strong>Account Number:</strong> <?php echo htmlspecialchars($student['Account_No']); ?></div>
<div class="detail-item"><strong>IFSC Code:</strong> <?php echo htmlspecialchars($student['IFSC_Code']); ?></div>
<div class="detail-item"><strong>MICR Code:</strong> <?php echo htmlspecialchars($student['MICR_Code']); ?></div>
<div class="detail-item"><strong>Father Qualification:</strong> <?php echo htmlspecialchars($student['Father_Qualification']); ?></div>
<div class="detail-item"><strong>Mother Qualification:</strong> <?php echo htmlspecialchars($student['Mother_Qualification']); ?></div>
<div class="detail-item"><strong>Identification Mark 1:</strong> <?php echo htmlspecialchars($student['Identification_Mark1']); ?></div>
<div class="detail-item"><strong>Identification Mark 2:</strong> <?php echo htmlspecialchars($student['Identification_Mark2']); ?></div>

            </div>
        </div>

        <!-- Scholarship Scheme Details Section -->
        <div class="details-section">
            <h3>Scholarship Scheme Details</h3>
            <div class="details-grid">
                <div class="detail-item"><strong>Scheme Name:</strong> <?php echo htmlspecialchars($scheme['scheme_name']); ?></div>
                <div class="detail-item"><strong>Applicable Income:</strong> <?php echo htmlspecialchars($scheme['applicable_income'] ?? 'N/A'); ?></div>
                <div class="detail-item"><strong>Applicable Caste:</strong> <?php echo htmlspecialchars($scheme['applicable_caste'] ?? 'N/A'); ?></div>
                <div class="detail-item"><strong>Applicable Gender:</strong> <?php echo htmlspecialchars($scheme['applicable_gender'] ?? 'N/A'); ?></div>
            </div>
        </div>

        <!-- Application Details Section -->
        <div class="details-section">
            <h3>Application Details</h3>
            <div class="details-grid">
                <div class="detail-item"><strong>Application Date:</strong> <?php echo htmlspecialchars($application['application_date']); ?></div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="action-buttons">
            <a href="process_application.php?action=approve&id=<?php echo $id; ?>" class="btn approve-btn">Approve</a>
            <a href="process_application.php?action=reject&id=<?php echo $id; ?>" class="btn reject-btn">Reject</a>
            <a href="applied_students.php" class="btn back-btn">Back</a>
        </div>
    </div>

    <script>
        function toggleSidebar() {
            document.getElementById("sidebar").classList.toggle("active");
        }
    </script>
</body>
</html>