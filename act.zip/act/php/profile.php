<?php
session_start();
date_default_timezone_set("Asia/Kolkata");
$currentDateTime = date("Y-m-d H:i:s");

// Redirect to login if not logged in
if (!isset($_SESSION['username']) || !isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'student') {
    header("Location: login.php");
    exit();
}

// Include database configuration
include 'db_connect.php';

// Fetch register_number using username from users table
$username = mysqli_real_escape_string($conn, $_SESSION['username']);
$sql_user = "SELECT register_number FROM users WHERE username = '$username'";
$result_user = mysqli_query($conn, $sql_user);

$register_number = null;
if ($result_user && mysqli_num_rows($result_user) > 0) {
    $user = mysqli_fetch_assoc($result_user);
    $register_number = $user['register_number'];
}

if (!$register_number) {
    // If register_number couldn't be fetched, redirect to login
    echo "No register_number found for username: " . htmlspecialchars($username) . ". Redirecting to login...\n";
    header("Location: login.php");
    exit();
}

// Fetch student details from students table using register_number
$sql_student = "SELECT * FROM students WHERE register_number = '$register_number'";
$result_student = mysqli_query($conn, $sql_student);

$student_details = null;
if ($result_student && mysqli_num_rows($result_student) > 0) {
    $student_details = mysqli_fetch_assoc($result_student);
} else {
    // If no student details found, display an error message
    $error_message = "No student details found for register number: " . htmlspecialchars($register_number);
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Profile</title>
    <link rel="stylesheet" href="../css/dashboard_style.css">
    <link rel="stylesheet" href="../css/profile_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>
    <!-- Top Ribbon -->
    <div class="top-ribbon">
        <div class="ribbon-left">
            <button class="menu-btn" onclick="toggleSidebar()">☰</button>
            STUDENT SCHOLARSHIP PORTAL
        </div>
        <div class="ribbon-right">
            <span>Welcome, <?php echo htmlspecialchars($username); ?></span>
            <span><?php echo $currentDateTime; ?></span>
            <div class="dropdown">
                <button class="dropbtn">▼</button>
                <div class="dropdown-content">
                    <a href="profile.php">Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Sidebar Navigation -->
    <div class="sidebar" id="sidebar">
        <ul>
            <li><a href="dashboard_student.php">Dashboard</a></li>
            <li><a href="schemes_stu.php">Scholarship Schemes</a></li>
            <li><a href="app_stu.php">Approved Students</a></li>
            <li><a href="rejected_students_stu.php">Rejected Students</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="content">
        <h2 class="title">Student Profile</h2>

        <?php if (isset($error_message)): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php else: ?>
            <div class="profile-container">
                <div class="profile-header">
                    <h3><?php echo htmlspecialchars($student_details['Name_of_the_Student'] ?? 'N/A'); ?></h3>
                    <p>Register Number: <?php echo htmlspecialchars($student_details['register_number']); ?></p>
                </div>
                <div class="profile-details">
                    <div class="detail-row">
                        <span class="detail-label">Course:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['Course'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Department:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['department'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Date of Birth:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['date_of_birth'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Gender:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['Gender'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Community:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['Community'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Religion:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['Religion'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Father's Name:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['father_name'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Mother's Name:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['mother_name'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Address:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['Address'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Blood Group:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['Blood_Group'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Contact No:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['Contact_No'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Email:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['E_Mail'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Aadhar No:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['Aadhar_No'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">PAN No:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['PAN_No'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Bank Name:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['BANK_Name'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Branch:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['Branch'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Account No:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['Account_No'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">IFSC Code:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['IFSC_Code'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">MICR Code:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['MICR_Code'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Father's Qualification:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['Father_Qualification'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Father's Occupation:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['Father_Occupation'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Father's Annual Income:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['Father_Annual_Income'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Mother's Qualification:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['Mother_Qualification'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Mother's Occupation:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['Mother_Occupation'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">UMIS Number:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['UMIS_NUMBER'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Identification Mark 1:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['Identification_Mark1'] ?? 'N/A'); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Identification Mark 2:</span>
                        <span class="detail-value"><?php echo htmlspecialchars($student_details['Identification_Mark2'] ?? 'N/A'); ?></span>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
        function toggleSidebar() {
            let sidebar = document.getElementById("sidebar");
            sidebar.classList.toggle("active");
        }
    </script>
</body>
</html>