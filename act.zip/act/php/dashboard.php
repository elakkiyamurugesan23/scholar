<?php
session_start();
date_default_timezone_set("Asia/Kolkata");
$currentDateTime = date("Y-m-d H:i:s");

if (!isset($_SESSION['username'])) {
    $_SESSION['username'] = "Guest";
}

// Include database configuration
include 'db_connect.php';

// Fetch counts from the respective tables
$sql_schemes = "SELECT COUNT(*) as total FROM scholarship_schemes";
$result_schemes = mysqli_query($conn, $sql_schemes);
$schemes_count = $result_schemes ? mysqli_fetch_assoc($result_schemes)['total'] : 0;

$sql_students = "SELECT COUNT(*) as total FROM students";
$result_students = mysqli_query($conn, $sql_students);
$students_count = $result_students ? mysqli_fetch_assoc($result_students)['total'] : 0;

$sql_approved = "SELECT COUNT(*) as total FROM approved";
$result_approved = mysqli_query($conn, $sql_approved);
$approved_count = $result_approved ? mysqli_fetch_assoc($result_approved)['total'] : 0;

$sql_rejected = "SELECT COUNT(*) as total FROM rejected";
$result_rejected = mysqli_query($conn, $sql_rejected);
$rejected_count = $result_rejected ? mysqli_fetch_assoc($result_rejected)['total'] : 0;

// Fetch count of applied students from scholarship_applications
$sql_applied = "SELECT COUNT(*) as total FROM scholarship_applications";
$result_applied = mysqli_query($conn, $sql_applied);
$applied_count = $result_applied ? mysqli_fetch_assoc($result_applied)['total'] : 0;

// Fetch count of pending applications from scholarship_applications
$sql_pending = "SELECT COUNT(*) as total FROM scholarship_applications ";
$result_pending = mysqli_query($conn, $sql_pending);
$pending_count = $result_pending ? mysqli_fetch_assoc($result_pending)['total'] : 0;

// Calculate total applications (applied + approved + rejected)
$total_applications = $applied_count + $approved_count + $rejected_count;

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="../css/dashboard_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> <!-- Font Awesome for icons -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> <!-- Chart.js CDN -->
    <script>
        function toggleSidebar() {
            let sidebar = document.getElementById("sidebar");
            sidebar.classList.toggle("active");
        }

        // Real-time Calendar Script
        function renderCalendar() {
            const today = new Date();
            const month = today.getMonth();
            const year = today.getFullYear();
            const firstDay = new Date(year, month, 1).getDay();
            const daysInMonth = new Date(year, month + 1, 0).getDate();

            const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            document.getElementById("calendar-title").innerText = `${monthNames[month]} ${year}`;

            const calendarDays = document.getElementById("calendar-days");
            calendarDays.innerHTML = `
                <span>Su</span><span>Mo</span><span>Tu</span><span>We</span><span>Th</span><span>Fr</span><span>Sa</span>
            `;

            // Add empty slots for days before the 1st
            for (let i = 0; i < firstDay; i++) {
                calendarDays.innerHTML += `<span></span>`;
            }

            // Add days of the month
            for (let day = 1; day <= daysInMonth; day++) {
                if (day === today.getDate()) {
                    calendarDays.innerHTML += `<span class="today">${day}</span>`;
                } else {
                    calendarDays.innerHTML += `<span>${day}</span>`;
                }
            }
        }

        // Chart Configuration
        window.onload = function() {
            renderCalendar();

            const ctx = document.getElementById('myChart').getContext('2d');
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Students', 'Approved', 'Rejected', 'Total Applications', 'Pending'],
                    datasets: [{
                        label: 'Count',
                        data: [<?php echo $students_count; ?>, <?php echo $approved_count; ?>, <?php echo $rejected_count; ?>, <?php echo $total_applications; ?>, <?php echo $pending_count; ?>],
                        backgroundColor: [
                            'rgba(75, 192, 192, 0.6)', // Teal for Students
                            'rgba(54, 162, 235, 0.6)', // Blue for Approved
                            'rgba(255, 99, 132, 0.6)', // Red for Rejected
                            'rgba(255, 206, 86, 0.6)', // Yellow for Total Applications
                            'rgba(153, 102, 255, 0.6)' // Purple for Pending
                        ],
                        borderColor: [
                            'rgba(75, 192, 192, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 99, 132, 1)',
                            'rgba(255, 206, 86, 1)',
                            'rgba(153, 102, 255, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true,
                            title: {
                                display: true,
                                text: 'Number of Applications'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: true,
                            position: 'top'
                        },
                        title: {
                            display: true,
                            text: 'Application Statistics'
                        }
                    }
                }
            });
        };
    </script>
</head>
<body>
    <!-- Top Ribbon -->
    <div class="top-ribbon">
        <div class="ribbon-left">
            <button class="menu-btn" onclick="toggleSidebar()">☰</button>
            STUDENT SCHOLARSHIP PORTAL
        </div>
        <div class="ribbon-right">
            <span>Welcome, <?php echo $_SESSION['username']; ?>!</span>
            <span><?php echo $currentDateTime; ?></span>
            <div class="dropdown">
                <button class="dropbtn">☰</button>
                <div class="dropdown-content">
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Sidebar Navigation -->
    <div id="sidebar" class="sidebar">
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="student_info.php">Student Information</a></li>
            <li><a href="schemes.php">Scholarship Schemes</a></li>
            <li><a href="applied_students.php">Applied Students</a></li>
            <li><a href="app.php">Approved Students</a></li>
            <li><a href="rejected_students.php">Rejected Students</a></li>
            <li><a href="add_admin.php">Add New admin</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="content">
        <div class="dashboard-grid">
            <div class="dashboard-panel schemes-panel">
                <i class="fas fa-university"></i>
                <h3>Schemes</h3>
                <p class="count"><?php echo $schemes_count; ?></p>
            </div>
            <div class="dashboard-panel students-panel">
                <i class="fas fa-users"></i>
                <h3>Students</h3>
                <p class="count"><?php echo $students_count; ?></p>
            </div>
            <div class="dashboard-panel approved-panel">
                <i class="fas fa-check-circle"></i>
                <h3>Approved</h3>
                <p class="count"><?php echo $approved_count; ?></p>
            </div>
            <div class="dashboard-panel rejected-panel">
                <i class="fas fa-times-circle"></i>
                <h3>Rejected</h3>
                <p class="count"><?php echo $rejected_count; ?></p>
            </div>
            <div class="dashboard-panel total-panel">
                <i class="fas fa-clipboard-list"></i>
                <h3>Total Applications</h3>
                <p class="count"><?php echo $total_applications; ?></p>
            </div>
            <div class="dashboard-panel pending-panel">
                <i class="fas fa-hourglass-half"></i>
                <h3>Pending Applications</h3>
                <p class="count"><?php echo $pending_count; ?></p>
            </div>
            <div class="dashboard-panel calendar-panel">
                <h3>Calendar</h3>
                <div class="calendar-content">
                    <span id="calendar-title"></span>
                    <div id="calendar-days" class="calendar-days"></div>
                </div>
            </div>
        </div>
        <div class="chart-container">
            <canvas id="myChart"></canvas>
        </div>
        <div class="dashboard-update">Dashboard Updated: <?php echo date("d-m-Y"); ?></div>
    </div>
</body>
</html>