<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

$conn = new mysqli("localhost", "root", "", "act");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = isset($_SESSION['username']) ? $_SESSION['username'] : "Guest";
$currentDateTime = date("Y-m-d H:i:s");

// Search functionality
$searchQuery = "";
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['search'])) {
    $search = $conn->real_escape_string($_GET['search']);
    $searchBy = $conn->real_escape_string($_GET['search_by']);

    if (!empty($search) && !empty($searchBy)) {
        $searchQuery = "WHERE $searchBy LIKE '%$search%'";
    }
}

// Fetch student data
$query = "SELECT * FROM students $searchQuery";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Information - Scholarship Portal</title>
    <link rel="stylesheet" href="../css/student_info_style.css">
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById("sidebar");
            const content = document.querySelector(".content");
            sidebar.classList.toggle("open");
            content.classList.toggle("shifted");
        }
    </script>
</head>
<body>

<div class="top-ribbon">
    <div class="ribbon-left">
        <button class="menu-btn" onclick="toggleSidebar()">☰</button>
        STUDENT SCHOLARSHIP PORTAL
    </div>
    <div class="ribbon-right">
        <div class="user-info">
            <span>Welcome, <?php echo htmlspecialchars($username); ?>!</span>
            <span><?php echo $currentDateTime; ?></span>
        </div>
        <div class="dropdown">
            <button class="dropbtn">☰</button>
            <div class="dropdown-content">
                <a href="logout.php">Logout</a>
            </div>
        </div>
    </div>
</div>

<div class="search-ribbon">
    <form method="GET">
        <label for="search">Search:</label>
        <input type="text" name="search" placeholder="Enter search keyword">
        <select name="search_by">
            <option value="register_number">Register Number</option>
            <option value="UMIS_NUMBER">UMIS Number</option>
            <option value="Name_of_the_Student">Student Name</option>
            <option value="Aadhar_No">Aadhar Number</option>
            <option value="Course">Course</option>
            <option value="department">Department</option>
        </select>
        <button type="submit">Search</button>
    </form>
</div>

<div id="sidebar" class="sidebar">
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="student_info.php">Student Information</a></li>
        <li><a href="schemes.php">Scholarship Schemes</a></li>
        <li><a href="applied_students.php">Applied Students</a></li>
        <li><a href="app.php">Approved Students</a></li>
        <li><a href="rejected_students.php">Rejected Students</a></li>
    </ul>
</div>

<div class="content">
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Student Name</th>
                    <th>Register Number</th>
                    <th>Gender</th>
                    <th>Date of Birth</th>
                    <th>Course</th>
                    <th>Department</th>
                    <th>Community</th>
                    <th>Religion</th>
                    <th>Phone Number</th>
                    <th>UMIS Number</th>
                    <th>Aadhar Number</th>
                    <th>Address</th>
                    <th>Father Name</th>
                    <th>Mother Name</th>
                    <th>Father Occupation</th>
                    <th>Mother Occupation</th>
                    <th>Annual Family Income</th>
                    <th>Blood Group</th>
                    <th>Email</th>
                    <th>PAN Number</th>
                    <th>Bank Name</th>
                    <th>Branch</th>
                    <th>Account Number</th>
                    <th>IFSC Code</th>
                    <th>MICR Code</th>
                    <th>Father Qualification</th>
                    <th>Mother Qualification</th>
                    <th>Identification Mark 1</th>
                    <th>Identification Mark 2</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>" . htmlspecialchars($row['Name_of_the_Student']) . "</td>
                            <td>" . htmlspecialchars($row['register_number']) . "</td>
                            <td>" . htmlspecialchars($row['Gender']) . "</td>
                            <td>" . htmlspecialchars($row['date_of_birth']) . "</td>
                            <td>" . htmlspecialchars($row['Course']) . "</td>
                            <td>" . htmlspecialchars($row['department']) . "</td>
                            <td>" . htmlspecialchars($row['Community']) . "</td>
                            <td>" . htmlspecialchars($row['Religion']) . "</td>
                            <td>" . htmlspecialchars($row['Contact_No']) . "</td>
                            <td>" . htmlspecialchars($row['UMIS_NUMBER']) . "</td>
                            <td>" . htmlspecialchars($row['Aadhar_No']) . "</td>
                            <td>" . htmlspecialchars($row['Address']) . "</td>
                            <td>" . htmlspecialchars($row['father_name']) . "</td>
                            <td>" . htmlspecialchars($row['mother_name']) . "</td>
                            <td>" . htmlspecialchars($row['Father_Occupation']) . "</td>
                            <td>" . htmlspecialchars($row['Mother_Occupation']) . "</td>
                            <td>" . htmlspecialchars($row['Father_Annual_Income']) . "</td>
                            <td>" . htmlspecialchars($row['Blood_Group']) . "</td>
                            <td>" . htmlspecialchars($row['E_Mail']) . "</td>
                            <td>" . htmlspecialchars($row['PAN_No']) . "</td>
                            <td>" . htmlspecialchars($row['Bank_Name']) . "</td>
                            <td>" . htmlspecialchars($row['Branch']) . "</td>
                            <td>" . htmlspecialchars($row['Account_No']) . "</td>
                            <td>" . htmlspecialchars($row['IFSC_Code']) . "</td>
                            <td>" . htmlspecialchars($row['MICR_Code']) . "</td>
                            <td>" . htmlspecialchars($row['Father_Qualification']) . "</td>
                            <td>" . htmlspecialchars($row['Mother_Qualification']) . "</td>
                            <td>" . htmlspecialchars($row['Identification_Mark1']) . "</td>
                            <td>" . htmlspecialchars($row['Identification_Mark2']) . "</td>
                            <td>
                                <a href='modify.php?id=" . htmlspecialchars($row['register_number']) . "' class='edit-btn'>Modify</a> 
                                <a href='delete.php?id=" . htmlspecialchars($row['register_number']) . "' class='delete-btn' onclick='return confirm(\"Are you sure?\")'>Delete</a>
                            </td>
                        </tr>";
                    }
                } else {
                    echo "<tr><td colspan='30'>No student data found.</td></tr>";
                }
                ?>
            </tbody>
        </table>

        <div style="text-align: center; margin-top: 20px;">
            <a href="add_student.php" style="background-color: #ff6600; color: white; padding: 12px 25px; font-size: 16px; border-radius: 8px; text-decoration: none; font-weight: bold; display: inline-block;">
                + Add New Student
                <script src="../js/pt.js"></script>
            </a>
        </div>
    </div>
</div>

</body>
</html>