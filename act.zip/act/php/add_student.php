<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

$conn = new mysqli("localhost", "root", "", "act");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert Student Data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $Course = $conn->real_escape_string($_POST['Course']);
    $department = $conn->real_escape_string($_POST['department']);
    $register_number = $conn->real_escape_string($_POST['register_number']);
    $Name_of_the_Student = $conn->real_escape_string($_POST['Name_of_the_Student']);
    $date_of_birth = $conn->real_escape_string($_POST['date_of_birth']);
    $Gender = $conn->real_escape_string($_POST['Gender']);
    $Community = $conn->real_escape_string($_POST['Community']);
    $Religion = $conn->real_escape_string($_POST['Religion']);
    $father_name = $conn->real_escape_string($_POST['father_name']);
    $mother_name = $conn->real_escape_string($_POST['mother_name']);
    $Address = $conn->real_escape_string($_POST['Address']);
    $Blood_Group = $conn->real_escape_string($_POST['Blood_Group']);
    $Contact_No = $conn->real_escape_string($_POST['Contact_No']);
    $E_Mail = $conn->real_escape_string($_POST['E_Mail']);
    $Aadhar_No = $conn->real_escape_string($_POST['Aadhar_No']);
    $PAN_No = $conn->real_escape_string($_POST['PAN_No']);
    $Bank_Name = $conn->real_escape_string($_POST['Bank_Name']);
    $Branch = $conn->real_escape_string($_POST['Branch']);
    $Account_No = $conn->real_escape_string($_POST['Account_No']);
    $IFSC_Code = $conn->real_escape_string($_POST['IFSC_Code']);
    $MICR_Code = $conn->real_escape_string($_POST['MICR_Code']);
    $Father_Qualification = $conn->real_escape_string($_POST['Father_Qualification']);
    $Father_Occupation = $conn->real_escape_string($_POST['Father_Occupation']);
    $Father_Annual_Income = $conn->real_escape_string($_POST['Father_Annual_Income']);
    $Mother_Qualification = $conn->real_escape_string($_POST['Mother_Qualification']);
    $Mother_Occupation = $conn->real_escape_string($_POST['Mother_Occupation']);
    $UMIS_NUMBER = $conn->real_escape_string($_POST['UMIS_NUMBER']);
    $Identification_Mark1 = $conn->real_escape_string($_POST['Identification_Mark1']);
    $Identification_Mark2 = $conn->real_escape_string($_POST['Identification_Mark2']);

    // Check if Aadhar Number Already Exists
    $check_sql = "SELECT * FROM students WHERE Aadhar_No = '$Aadhar_No'";
    $result = $conn->query($check_sql);

    if ($result->num_rows > 0) {
        echo "Error: A student with this Aadhar Number already exists!";
    } else {
        // Insert query for the updated table structure
        $sql = "INSERT INTO students (
            Course, department, register_number, Name_of_the_Student, date_of_birth, Gender, Community, Religion, 
            father_name, mother_name, Address, Blood_Group, Contact_No, E_Mail, Aadhar_No, PAN_No, Bank_Name, 
            Branch, Account_No, IFSC_Code, MICR_Code, Father_Qualification, Father_Occupation, Father_Annual_Income, 
            Mother_Qualification, Mother_Occupation, UMIS_NUMBER, Identification_Mark1, Identification_Mark2
        ) VALUES (
            '$Course', '$department', '$register_number', '$Name_of_the_Student', '$date_of_birth', '$Gender', '$Community', '$Religion',
            '$father_name', '$mother_name', '$Address', '$Blood_Group', '$Contact_No', '$E_Mail', '$Aadhar_No', '$PAN_No', '$Bank_Name',
            '$Branch', '$Account_No', '$IFSC_Code', '$MICR_Code', '$Father_Qualification', '$Father_Occupation', '$Father_Annual_Income',
            '$Mother_Qualification', '$Mother_Occupation', '$UMIS_NUMBER', '$Identification_Mark1', '$Identification_Mark2'
        )";

        if ($conn->query($sql) === TRUE) {
            header("Location: student_info.php?success=Student added successfully");
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Student - Scholarship Portal</title>
    <link rel="stylesheet" href="../css/add_student_style.css">
</head>
<body>

<!-- Top Ribbon -->
<div class="top-ribbon">
    <div class="ribbon-left">
        <a href="student_info.php" class="back-btn">← Back</a>
        STUDENT SCHOLARSHIP PORTAL
    </div>
</div>

<!-- Add Student Form -->
<div class="form-container">
    <h1>Add New Student</h1>
    <form action="add_student.php" method="POST">
        <label>Course:</label>
        <input type="text" name="Course" required>

        <label>Department:</label>
        <input type="text" name="department" required>

        <label>Register Number:</label>
        <input type="text" name="register_number" required>

        <label>Student Name:</label>
        <input type="text" name="Name_of_the_Student" required>

        <label>Date of Birth:</label>
        <input type="date" name="date_of_birth" required>

        <label>Gender:</label>
        <select name="Gender" required>
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
        </select>

        <label>Community:</label>
        <input type="text" name="Community" required>

        <label>Religion:</label>
        <input type="text" name="Religion" required>

        <label>Father Name:</label>
        <input type="text" name="father_name" required>

        <label>Mother Name:</label>
        <input type="text" name="mother_name" required>

        <label>Address:</label>
        <textarea name="Address" required></textarea>

        <label>Blood Group:</label>
        <input type="text" name="Blood_Group" required>

        <label>Contact Number:</label>
        <input type="text" name="Contact_No" required>

        <label>Email:</label>
        <input type="email" name="E_Mail" required>

        <label>Aadhar Number:</label>
        <input type="text" name="Aadhar_No" required>

        <label>PAN Number:</label>
        <input type="text" name="PAN_No">

        <label>Bank Name:</label>
        <input type="text" name="Bank_Name">

        <label>Branch:</label>
        <input type="text" name="Branch">

        <label>Account Number:</label>
        <input type="text" name="Account_No">

        <label>IFSC Code:</label>
        <input type="text" name="IFSC_Code">

        <label>MICR Code:</label>
        <input type="text" name="MICR_Code">

        <label>Father Qualification:</label>
        <input type="text" name="Father_Qualification" required>

        <label>Father Occupation:</label>
        <input type="text" name="Father_Occupation" required>

        <label>Father Annual Income:</label>
        <input type="number" name="Father_Annual_Income" required>

        <label>Mother Qualification:</label>
        <input type="text" name="Mother_Qualification" required>

        <label>Mother Occupation:</label>
        <input type="text" name="Mother_Occupation" required>

        <label>UMIS Number:</label>
        <input type="text" name="UMIS_NUMBER" required>

        <label>Identification Mark 1:</label>
        <input type="text" name="Identification_Mark1" required>

        <label>Identification Mark 2:</label>
        <input type="text" name="Identification_Mark2" required>

        <button type="submit">Add Student</button>

        <button onclick="goBack()" class="back-btn">🔙 Back</button>
    </form>
</div>

<script>
function goBack() {
    window.location.href = "../php/student_info.php"; // Redirect to Student Information Page
}
</script>

</body>
</html>