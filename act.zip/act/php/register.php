<?php
session_start();
include("db_connect.php");

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $register_number = $_POST['register_number'];
    $email = $_POST['email'];
    $phone_number = $_POST['phone_number'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validate passwords match
    if ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        // Check if register_number exists in students table
        $sql = "SELECT * FROM students WHERE register_number = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $register_number);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 0) {
            $error = "Register number not found in student records.";
        } else {
            // Check if username already exists in users table
            $sql = "SELECT * FROM users WHERE username = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $error = "Username already exists.";
            } else {
                // Check if email already exists
                $sql = "SELECT * FROM users WHERE email = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    $error = "Email already registered.";
                } else {
                    // Check if register_number already exists in users table
                    $sql = "SELECT * FROM users WHERE register_number = ?";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("s", $register_number);
                    $stmt->execute();
                    $result = $stmt->get_result();

                    if ($result->num_rows > 0) {
                        $error = "Register number already registered.";
                    } else {
                        // Hash password and insert into users table
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                        $user_type = "student"; // Fixed as student

                        $sql = "INSERT INTO users (name, username, register_number, email, phone_number, password, user_type) VALUES (?, ?, ?, ?, ?, ?, ?)";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("sssssss", $name, $username, $register_number, $email, $phone_number, $hashed_password, $user_type);

                        if ($stmt->execute()) {
                            $success = "Registration successful! Please login.";
                        } else {
                            $error = "Error during registration. Please try again.";
                        }
                    }
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>
    <link rel="stylesheet" href="../css/registerstyle.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet"> <!-- Poppins font -->
</head>
<body>
    <div class="register-container">
        <h2>Student Registration</h2>
        <?php 
        if ($error) { echo "<p class='error'>$error</p>"; }
        if ($success) { echo "<p class='success'>$success</p>"; }
        ?>
        <form action="register.php" method="POST">
            <input type="text" name="name" placeholder="Full Name" required>
            <input type="text" name="username" placeholder="Username" required>
            <input type="text" name="register_number" placeholder="Register Number" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="tel" name="phone_number" placeholder="Phone Number" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <button type="submit">Register</button>
        </form>
        <div class="additional-links">
            <a href="login.php" class="login-link">Back to Login</a>
        </div>
    </div>
</body>
</html>