<?php
include_once 'db_connect.php';

if ($conn) {
    echo "Database Connection Successful!";
} else {
    echo "Database Connection Failed!";
}
?>
