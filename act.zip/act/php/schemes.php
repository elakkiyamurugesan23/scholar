<?php
session_start();
date_default_timezone_set("Asia/Kolkata");
$currentDateTime = date("Y-m-d h:i:s");

include 'db_connect.php'; // Include database connection

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Handle scheme removal
if (isset($_GET['remove_scheme_id'])) {
    $scheme_id = mysqli_real_escape_string($conn, $_GET['remove_scheme_id']);
    $delete_query = "DELETE FROM scholarship_schemes WHERE id = '$scheme_id'";
    if (mysqli_query($conn, $delete_query)) {
        header("Location: schemes.php?success=Scheme removed successfully");
        exit();
    } else {
        $error = "Error removing scheme: " . mysqli_error($conn);
    }
}

$query = "SELECT * FROM scholarship_schemes";
$result = mysqli_query($conn, $query);

$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Guest'; // Default to 'Guest' if not set
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Schemes</title>
    <link rel="stylesheet" href="../css/approved_scholarships.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const menuBtn = document.querySelector(".menu-btn");
            const sidebar = document.querySelector(".sidebar");
            const content = document.querySelector(".content");

            function toggleSidebar() {
                sidebar.classList.toggle("collapsed");
                content.classList.toggle("shifted");
                localStorage.setItem("sidebarCollapsed", sidebar.classList.contains("collapsed"));
            }

            menuBtn.addEventListener("click", function() {
                toggleSidebar();
                if (sidebar.classList.contains("collapsed")) {
                    content.style.marginLeft = "0px";
                } else {
                    content.style.marginLeft = "220px";
                }
            });

            const isCollapsed = localStorage.getItem("sidebarCollapsed") === "true";
            if (isCollapsed) {
                sidebar.classList.add("collapsed");
                content.classList.add("shifted");
                content.style.marginLeft = "0px";
            }
        });
    </script>
    <style>
    .action-btn {
        display: inline-block;
        padding: 5px 8px; /* Adjusted padding */
        margin: 0 2px; /* Adjusted margin */
        color: white;
        text-decoration: none;
        border-radius: 4px;
        border: none;
        cursor: pointer;
    }
    .apply-btn { background-color: #28a745; }
    .apply-btn:hover { background-color: #218838; }
    .modify-btn { background-color: #007bff; }
    .modify-btn:hover { background-color: #0069d9; }
    .remove-btn { background-color: #dc3545; }
    .remove-btn:hover { background-color: #c82333; }
    /* Adjust Action column width */
    table th:last-child,
    table td:last-child {
        width: 200px; /* Adjust this value as needed */
        text-align: center;
    }
</style>
</head>
<body>
    <div class="top-ribbon">
        <div class="ribbon-left">
            <button class="menu-btn" aria-label="Toggle Menu"><i class="fas fa-bars"></i></button>
            <h2>STUDENT SCHOLARSHIP PORTAL</h2>
        </div>
        <div class="ribbon-right">
            <span>Welcome, <?php echo htmlspecialchars($username); ?>!</span>
            <span><?php echo $currentDateTime; ?></span>
            <div class="dropdown">
                <button class="dropbtn">☰</button>
                <div class="dropdown-content">
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <div class="sidebar">
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="student_info.php">Student Information</a></li>
            <li><a href="schemes.php">Scholarship Schemes</a></li>
            <li><a href="applied_students.php">Applied Students</a></li>
            <li><a href="app.php">Approved Students</a></li>
            <li><a href="rejected_students.php">Rejected Students</a></li>
            <li><a href="add_admin.php">Add New Admin</a></li>
        </ul>
    </div>

    <div class="content">
        <div class="table-container">
            <div style="margin-bottom: 20px;">
                <a href="add_scheme.php" class="apply-btn action-btn">Add Schemes</a>
            </div>
            <?php if (isset($error)) : ?>
                <p style="color: red;"><?php echo $error; ?></p>
            <?php endif; ?>
            <?php if (isset($_GET['success'])) : ?>
                <p style="color: green;"><?php echo htmlspecialchars($_GET['success']); ?></p>
            <?php endif; ?>
            <table>
                <thead>
                    <tr>
                        <th>Scheme Name</th>
                        <th>Applicable Income</th>
                        <th>Applicable Caste</th>
                        <th>Applicable Gender</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                        <tr>
                            <td><?= htmlspecialchars($row['scheme_name']); ?></td>
                            <td><?= htmlspecialchars($row['applicable_income']); ?></td>
                            <td><?= htmlspecialchars($row['applicable_caste']); ?></td>
                            <td><?= htmlspecialchars($row['applicable_gender']); ?></td>
                            <td>
                                <a href="apply_scholarship.php?scheme_id=<?= $row['id']; ?>" class="action-btn apply-btn">Apply</a>
                                <a href="modify_scheme.php?scheme_id=<?= $row['id']; ?>" class="action-btn modify-btn">Modify</a>
                                <a href="schemes.php?remove_scheme_id=<?= $row['id']; ?>" class="action-btn remove-btn" onclick="return confirm('Are you sure you want to remove this scheme?');">Remove</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>