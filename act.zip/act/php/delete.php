<?php
// Start session (optional, depending on your application needs)
session_start();

// Set timezone
date_default_timezone_set('Asia/Kolkata');

// Establish database connection
$conn = new mysqli("localhost", "root", "", "act");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Delete Student Data
if (isset($_GET['id'])) {
    $register_number = $_GET['id'];

    $query = "DELETE FROM students WHERE register_number = ?";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }
    $stmt->bind_param("s", $register_number);

    if ($stmt->execute()) {
        header("Location: student_info.php?delete_success=1");
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }

    // Close the statement
    $stmt->close();
}

// Close the connection
$conn->close();
?>