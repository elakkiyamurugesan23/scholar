<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

$conn = new mysqli("localhost", "root", "", "act");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch all the updated fields from the form
    $register_number = $conn->real_escape_string($_POST['register_number']);
    $Course = $conn->real_escape_string($_POST['Course']);
    $department = $conn->real_escape_string($_POST['department']);
    $Name_of_the_Student = $conn->real_escape_string($_POST['Name_of_the_Student']);
    $date_of_birth = $conn->real_escape_string($_POST['date_of_birth']);
    $Gender = $conn->real_escape_string($_POST['Gender']);
    $Community = $conn->real_escape_string($_POST['Community']);
    $Religion = $conn->real_escape_string($_POST['Religion']);
    $father_name = $conn->real_escape_string($_POST['father_name']);
    $mother_name = $conn->real_escape_string($_POST['mother_name']);
    $Address = $conn->real_escape_string($_POST['Address']);
    $Blood_Group = $conn->real_escape_string($_POST['Blood_Group']);
    $Contact_No = $conn->real_escape_string($_POST['Contact_No']);
    $E_Mail = $conn->real_escape_string($_POST['E_Mail']);
    $Aadhar_No = $conn->real_escape_string($_POST['Aadhar_No']);
    $PAN_No = $conn->real_escape_string($_POST['PAN_No']);
    $Bank_Name = $conn->real_escape_string($_POST['Bank_Name']);
    $Branch = $conn->real_escape_string($_POST['Branch']);
    $Account_No = $conn->real_escape_string($_POST['Account_No']);
    $IFSC_Code = $conn->real_escape_string($_POST['IFSC_Code']);
    $MICR_Code = $conn->real_escape_string($_POST['MICR_Code']);
    $Father_Qualification = $conn->real_escape_string($_POST['Father_Qualification']);
    $Father_Occupation = $conn->real_escape_string($_POST['Father_Occupation']);
    $Father_Annual_Income = $conn->real_escape_string($_POST['Father_Annual_Income']);
    $Mother_Qualification = $conn->real_escape_string($_POST['Mother_Qualification']);
    $Mother_Occupation = $conn->real_escape_string($_POST['Mother_Occupation']);
    $UMIS_NUMBER = $conn->real_escape_string($_POST['UMIS_NUMBER']);
    $Identification_Mark1 = $conn->real_escape_string($_POST['Identification_Mark1']);
    $Identification_Mark2 = $conn->real_escape_string($_POST['Identification_Mark2']);

    // Update query with all fields
    $sql = "UPDATE students SET 
        Course=?, department=?, Name_of_the_Student=?, date_of_birth=?, Gender=?, Community=?, Religion=?, 
        father_name=?, mother_name=?, Address=?, Blood_Group=?, Contact_No=?, E_Mail=?, Aadhar_No=?, PAN_No=?, 
        Bank_Name=?, Branch=?, Account_No=?, IFSC_Code=?, MICR_Code=?, Father_Qualification=?, Father_Occupation=?, 
        Father_Annual_Income=?, Mother_Qualification=?, Mother_Occupation=?, UMIS_NUMBER=?, Identification_Mark1=?, 
        Identification_Mark2=? 
        WHERE register_number=?";

    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Prepare failed: " . $conn->error);
    }

    // Bind parameters (28 fields + 1 for WHERE clause = 29 total)
    $stmt->bind_param("sssssssssssssssssssssssssssss", 
        $Course, $department, $Name_of_the_Student, $date_of_birth, $Gender, $Community, $Religion, 
        $father_name, $mother_name, $Address, $Blood_Group, $Contact_No, $E_Mail, $Aadhar_No, $PAN_No, 
        $Bank_Name, $Branch, $Account_No, $IFSC_Code, $MICR_Code, $Father_Qualification, $Father_Occupation, 
        $Father_Annual_Income, $Mother_Qualification, $Mother_Occupation, $UMIS_NUMBER, $Identification_Mark1, 
        $Identification_Mark2, $register_number
    );

    if ($stmt->execute()) {
        $_SESSION['message'] = "Student details updated successfully!";
    } else {
        $_SESSION['message'] = "Error updating student details: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();

    header("Location: student_info.php");
    exit();
}
?>