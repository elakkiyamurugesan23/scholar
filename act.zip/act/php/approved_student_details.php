<?php
include 'db_connect.php';

if (isset($_GET['register_number'])) {
    $register_number = $_GET['register_number'];

    // Fetch student details from `scholarship_applications`
    $sql = "SELECT * FROM scholarship_applications WHERE register_number = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $register_number);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();

    if (!$student) {
        echo "<script>alert('Student not found!'); window.location.href='approved_scholarships.php';</script>";
        exit();
    }

    // Check if `scheme_id` exists in the `scholarship_applications` table
    if (!isset($student['scheme_id'])) {
        echo "<script>alert('Scheme ID not found!'); window.location.href='approved_scholarships.php';</script>";
        exit();
    }

    // Fetch scheme details from `scholarship_schemes` table
    $scheme_id = $student['scheme_id'];
    $sql_scheme = "SELECT * FROM scholarship_schemes WHERE scheme_id = ?";
    $stmt_scheme = $conn->prepare($sql_scheme);
    $stmt_scheme->bind_param("i", $scheme_id);
    $stmt_scheme->execute();
    $result_scheme = $stmt_scheme->get_result();
    $scheme = $result_scheme->fetch_assoc();

} else {
    echo "<script>alert('Invalid Request!'); window.location.href='approved_scholarships.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approved Student Details</title>
    <link rel="stylesheet" href="../css/approved_scholarships.css">
</head>
<body>

    <div class="container">
        <h2>Approved Student Details</h2>

        <table>
            <tr><th>Register Number</th><td><?php echo $student['register_number']; ?></td></tr>
            <tr><th>Name</th><td><?php echo $student['student_name']; ?></td></tr>
            <tr><th>Email</th><td><?php echo $student['email']; ?></td></tr>
            <tr><th>Phone Number</th><td><?php echo $student['phone_number']; ?></td></tr>
            <tr><th>Parent Phone</th><td><?php echo $student['parent_phone']; ?></td></tr>
            <tr><th>Father's Name</th><td><?php echo $student['father_name']; ?></td></tr>
            <tr><th>Mother's Name</th><td><?php echo $student['mother_name']; ?></td></tr>
            <tr><th>Batch</th><td><?php echo $student['batch']; ?></td></tr>
            <tr><th>Caste</th><td><?php echo $student['caste']; ?></td></tr>
            <tr><th>Religion</th><td><?php echo $student['religion']; ?></td></tr>
            <tr><th>Permanent Address</th><td><?php echo $student['permanent_address']; ?></td></tr>
            <tr><th>12th Marks</th><td><?php echo $student['marks_12th']; ?></td></tr>
            <tr><th>12th Percentage</th><td><?php echo $student['percentage_12th']; ?></td></tr>
            <tr><th>Family Annual Income</th><td><?php echo $student['family_income']; ?></td></tr>
            <tr><th>Application Date</th><td><?php echo $student['application_date']; ?></td></tr>
            <tr><th>Status</th><td><?php echo $student['status']; ?></td></tr>
        </table>

        <h3>Scholarship Scheme Details</h3>
        <table>
            <tr><th>Scheme Name</th><td><?php echo $scheme['scheme_name']; ?></td></tr>
            <tr><th>Description</th><td><?php echo $scheme['scheme_description']; ?></td></tr>
            <tr><th>Eligibility</th><td><?php echo $scheme['eligibility']; ?></td></tr>
        </table>

        <a href="approved_scholarships.php" class="back-btn">Back</a>
    </div>

</body>
</html>
