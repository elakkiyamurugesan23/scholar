<?php
session_start();
date_default_timezone_set("Asia/Kolkata");
$currentDateTime = date("Y-m-d H:i:s");

include 'db_connect.php'; // Include database connection

// Check if user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Fetch scholarship scheme details
if (!isset($_GET['scheme_id'])) {
    die("Invalid scholarship selection.");
}

$scheme_id = $_GET['scheme_id'];
$sql = "SELECT * FROM scholarship_schemes WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $scheme_id);
$stmt->execute();
$scheme_result = $stmt->get_result();
$scheme = $scheme_result->fetch_assoc();

// Fetch logged-in user's register number and student details
$username = $_SESSION['username'];
$sql = "SELECT register_number FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$user_result = $stmt->get_result();
$user = $user_result->fetch_assoc();

// Fetch student details using register number
$student = null;
if ($user && isset($user['register_number'])) {
    $register_number = $user['register_number'];
    $sql = "SELECT * FROM students WHERE register_number = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $register_number);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();
}

// Apply Scholarship
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['apply_scholarship'])) {
    $register_number = $_POST['register_number'];
    $Name_of_the_Student = $_POST['Name_of_the_Student'];

    $sql = "INSERT INTO scholarship_applications (register_number, Name_of_the_Student, scheme_id, scheme_name) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssis", $register_number, $Name_of_the_Student, $scheme['id'], $scheme['scheme_name']);

    if ($stmt->execute()) {
        echo "<script>alert('Scholarship application submitted successfully!');</script>";
    } else {
        echo "<script>alert('Error submitting application.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply for Scholarship</title>
    <link rel="stylesheet" type="text/css" href="../css/apply_scholarship_stu.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> <!-- Font Awesome for icons -->
    <script>
        function toggleSidebar() {
            let sidebar = document.getElementById("sidebar");
            sidebar.classList.toggle("active");
        }
    </script>
</head>
<body>
    <!-- Top Ribbon -->
    <div class="top-ribbon">
        <div class="ribbon-left">
            <button class="menu-btn" onclick="toggleSidebar()">☰</button>
            STUDENT SCHOLARSHIP PORTAL
        </div>
        <div class="ribbon-right">
            <span>Welcome, <?php echo htmlspecialchars($username); ?>!</span>
            <span><?php echo $currentDateTime; ?></span>
            <div class="dropdown">
                <button class="dropbtn">☰</button>
                <div class="dropdown-content">
                    <a href="profile.php">Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Sidebar Navigation -->
    <div id="sidebar" class="sidebar">
        <ul>
            <li><a href="dashboard_student.php">Dashboard</a></li>
            <li><a href="schemes_stu.php">Scholarship Schemes</a></li>
            <li><a href="app_stu.php">Approved Students</a></li>
            <li><a href="rejected_students_stu.php">Rejected Students</a></li>
        </ul>
    </div>

    <!-- Content Area -->
    <div class="content">
        <a href="javascript:history.back()" class="back-button">Back</a>

        <h2>Scholarship Scheme Details</h2>
        <table>
            <tr><th>Scheme Name</th><td><?= htmlspecialchars($scheme['scheme_name']); ?></td></tr>
            <tr><th>Applicable Income</th><td><?= htmlspecialchars($scheme['applicable_income']); ?></td></tr>
            <tr><th>Applicable Caste</th><td><?= htmlspecialchars($scheme['applicable_caste']); ?></td></tr>
            <tr><th>Applicable Gender</th><td><?= htmlspecialchars($scheme['applicable_gender']); ?></td></tr>
        </table>

        <?php if ($student): ?>
            <h2>Your Details</h2>
            <table>
            <tr><th>Student Name</th><td><?=htmlspecialchars($student['Name_of_the_Student']); ?></td></tr>
              <tr><th>Register Number</th><td><?= htmlspecialchars($student['register_number']); ?></td></tr>
              <tr><th>Gender</th><td><?= htmlspecialchars($student['Gender']); ?></td></tr>
              <tr><th>Date of Birth</th><td><?= htmlspecialchars($student['date_of_birth']); ?></td></tr>
              <tr><th>Course</th><td><?= htmlspecialchars($student['Course']); ?></td></tr>
              <tr><th>Department</th><td><?= htmlspecialchars($student['department']); ?></td></tr>
              <tr><th>Community</th><td><?= htmlspecialchars($student['Community']); ?></td></tr>
              <tr><th>Religion</th><td><?= htmlspecialchars($student['Religion']); ?></td></tr>
              <tr><th>Phone Number</th><td><?= htmlspecialchars($student['Contact_No']); ?></td></tr>
              <tr><th>UMIS Number</th><td><?= htmlspecialchars($student['UMIS_NUMBER']); ?></td></tr>
              <tr><th>Aadhar Number</th><td><?= htmlspecialchars($student['Aadhar_No']); ?></td></tr>
              <tr><th>Address</th><td><?= htmlspecialchars($student['Address']); ?></td></tr>
              <tr><th>Father Name</th><td><?= htmlspecialchars($student['father_name']); ?></td></tr>
              <tr><th>Mother Name</th><td><?= htmlspecialchars($student['mother_name']); ?></td></tr>
              <tr><th>Father Occupation</th><td><?= htmlspecialchars($student['Father_Occupation']); ?></td></tr>
              <tr><th>Mother Occupation</th><td><?= htmlspecialchars($student['Mother_Occupation']); ?></td></tr>
              <tr><th>Annual Family Income</th><td><?= htmlspecialchars($student['Father_Annual_Income']); ?></td></tr>
              <tr><th>Blood Group</th><td><?= htmlspecialchars($student['Blood_Group']); ?></td></tr>
              <tr><th>Email</th><td><?= htmlspecialchars($student['E_Mail']); ?></td></tr>
              <tr><th>PAN Number</th><td><?= htmlspecialchars($student['PAN_No']); ?></td></tr>
              <tr><th>Bank Name</th><td><?= htmlspecialchars($student['Bank_Name']); ?></td></tr>
              <tr><th>Branch</th><td><?= htmlspecialchars($student['Branch']); ?></td></tr>
              <tr><th>Account Number</th><td><?= htmlspecialchars($student['Account_No']); ?></td></tr>
              <tr><th>IFSC Code</th><td><?= htmlspecialchars($student['IFSC_Code']); ?></td></tr>
              <tr><th>MICR Code</th><td><?= htmlspecialchars($student['MICR_Code']); ?></td></tr>
              <tr><th>Father Qualification</th><td><?= htmlspecialchars($student['Father_Qualification']); ?></td></tr>
              <tr><th>Mother Qualification</th><td><?= htmlspecialchars($student['Mother_Qualification']); ?></td></tr>
              <tr><th>Identification Mark 1</th><td><?= htmlspecialchars($student['Identification_Mark1']); ?></td></tr>
              <tr><th>Identification Mark 2</th><td><?= htmlspecialchars($student['Identification_Mark2']); ?></td></tr>

            </table>

            <form method="post">
                <input type="hidden" name="register_number" value="<?= htmlspecialchars($student['register_number']); ?>">
                <input type="hidden" name="Name_of_the_Student" value="<?= htmlspecialchars($student['Name_of_the_Student']); ?>">
                <button type="submit" name="apply_scholarship" class="apply-button">Apply</button>
            </form>
        <?php else: ?>
            <p>No student information found for your account.</p>
        <?php endif; ?>
    </div>
</body>
</html>