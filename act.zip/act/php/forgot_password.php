<?php
session_start();
include("db_connect.php");

// Set the time zone to match your database (e.g., Asia/Kolkata for IST)
date_default_timezone_set('Asia/Kolkata'); // Adjust based on your database time zone

// Manually include the required PHPMailer files
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Initialize variables
$email = "";
$error = "";
$success = "";
$show_otp_form = false;

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['otp'])) {
        // Step 1: Send OTP
        $email = trim($_POST['email']);
        
        // Validate email
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Please enter a valid email address.";
        } else {
            // Check if email exists in the database
            $sql = "SELECT * FROM users WHERE email = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 1) {
                $user = $result->fetch_assoc();
                $user_id = $user['id'];

                // Generate a 6-digit OTP
                $otp = rand(100000, 999999);
                $expires_at = date("Y-m-d H:i:s", strtotime("+10 minutes")); // OTP expires in 10 minutes

                // Store the OTP in the database
                $sql = "INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("iss", $user_id, $otp, $expires_at);
                $stmt->execute();

                // Send the OTP via email using PHPMailer
                $subject = "Password Reset OTP";
                $message = "Hello,\n\nYou requested a password reset. Your OTP is: $otp\n\nThis OTP will expire in 10 minutes.\n\nIf you did not request this, please ignore this email.";

                $mail = new PHPMailer\PHPMailer\PHPMailer(true);
                try {
                    // Server settings
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com'; // Gmail SMTP server
                    $mail->SMTPAuth = true;
                    $mail->Username = 'balakalimuthu7720@gmail.com'; // Your Gmail address
                    $mail->Password = 'uryu lcsc eetb havu'; // Your Gmail app-specific password
                    $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;

                    // Recipients
                    $mail->setFrom('balakalimuthu7720@gmail.com', 'Student Scholarship Portal');
                    $mail->addAddress($email);

                    // Content
                    $mail->isHTML(false);
                    $mail->Subject = $subject;
                    $mail->Body = $message;

                    $mail->send();
                    $success = "An OTP has been sent to your email.";
                    $show_otp_form = true; // Show the OTP verification form
                    $_SESSION['reset_email'] = $email; // Store email in session for later use
                } catch (PHPMailer\PHPMailer\Exception $e) {
                    $error = "Failed to send the OTP email. Error: {$mail->ErrorInfo}";
                }
            } else {
                $error = "No account found with that email address.";
            }
        }
    } else {
        // Step 2: Verify OTP
        $email = $_SESSION['reset_email'];
        $otp = trim($_POST['otp']);

        // Validate OTP
        if (empty($otp) || !is_numeric($otp) || strlen($otp) != 6) {
            $error = "Please enter a valid 6-digit OTP.";
            $show_otp_form = true;
        } else {
            // Check if the OTP is valid and not expired
            $sql = "SELECT * FROM password_resets WHERE token = ? AND expires_at > NOW()";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $otp);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 1) {
                $reset = $result->fetch_assoc();
                $user_id = $reset['user_id'];
                $expires_at = $reset['expires_at'];
                $current_time = date('Y-m-d H:i:s');

                // Debugging: Log the OTP details
                error_log("OTP: $otp, Expires At: $expires_at, Current Time: $current_time");

                $_SESSION['user_id'] = $user_id; // Store user_id for password reset
                header("Location: reset_password.php");
                exit();
            } else {
                // Debugging: Check why the OTP failed
                $sql = "SELECT * FROM password_resets WHERE token = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $otp);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows === 0) {
                    $error = "Invalid OTP. No matching OTP found.";
                } else {
                    $reset = $result->fetch_assoc();
                    $expires_at = $reset['expires_at'];
                    $current_time = date('Y-m-d H:i:s');
                    $error = "OTP has expired. Expires At: $expires_at, Current Time: $current_time";
                }
                $show_otp_form = true;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="../css/forgot_password.css">
</head>
<body>
    <div class="forgot-password-container">
        <h2>Forgot Password</h2>
        <?php 
        if (!empty($error)) { 
            echo "<p class='error'>$error</p>"; 
        } 
        if (!empty($success)) { 
            echo "<p class='success'>$success</p>"; 
        } 
        ?>

        <?php if (!$show_otp_form) { ?>
            <!-- Email Form -->
            <form action="forgot_password.php" method="POST">
                <input type="email" name="email" placeholder="Enter your email" value="<?php echo htmlspecialchars($email); ?>" required>
                <button type="submit">Send OTP</button>
            </form>
        <?php } else { ?>
            <!-- OTP Verification Form -->
            <form action="forgot_password.php" method="POST">
                <input type="text" name="otp" placeholder="Enter the 6-digit OTP" required>
                <button type="submit">Verify OTP</button>
            </form>
        <?php } ?>

        <div class="additional-links">
            <a href="login.php" class="login-link">Back to Login</a>
            <a href="register.php" class="register-link">Register</a>
        </div>
    </div>
</body>
</html>