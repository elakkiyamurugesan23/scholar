<?php
// Start session safely
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Example: Fetch username from session (modify based on your session data)
$username = isset($_SESSION['username']) ? $_SESSION['username'] : "Guest";

// Get current date and time
date_default_timezone_set('Asia/Kolkata'); // Change timezone if needed
$currentDateTime = date("d-m-Y h:i A");
?>

<!-- Top Ribbon -->
<div class="top-ribbon">
    <div class="portal-name">STUDENT SCHOLARSHIP PORTAL</div>
    <div class="user-info">
        <span><?php echo "Welcome, " . $username; ?> | <?php echo $currentDateTime; ?></span>
        <button class="menu-btn" onclick="toggleSidebar()">☰</button>
    </div>
</div>

<!-- Sidebar (Hidden by Default) -->
<div id="sidebar" class="sidebar">
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="student_info.php">Student Information</a></li>
        <li><a href="scholarship_approval.php">Scholarship Approval</a></li>
        <li><a href="course_details.php">Course Details</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</div>
