<?php
$servername = "localhost";
$username = "root"; // Change if needed
$password = "";
$dbname = "act";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Database connection failed"]));
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $student_input = $_POST['student_search'];

    $sql = "SELECT * FROM students WHERE student_id = ? OR aadhar_number = ? OR umis_number = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $student_input, $student_input, $student_input);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();
        echo json_encode(["status" => "success"] + $student);
    } else {
        echo json_encode(["status" => "error", "message" => "Student not found"]);
    }
}

$conn->close();
?>
