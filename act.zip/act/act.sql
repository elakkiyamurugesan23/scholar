-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2025 at 08:42 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `act`
--

-- --------------------------------------------------------

--
-- Table structure for table `approved`
--

CREATE TABLE `approved` (
  `id` int(11) NOT NULL,
  `register_number` varchar(50) DEFAULT NULL,
  `Name_of_the_Student` varchar(100) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `date_of_birth` varchar(20) DEFAULT NULL,
  `Course` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `Community` varchar(50) DEFAULT NULL,
  `Religion` varchar(50) DEFAULT NULL,
  `Contact_No` varchar(15) DEFAULT NULL,
  `UMIS_NUMBER` varchar(50) DEFAULT NULL,
  `Aadhar_No` varchar(12) DEFAULT NULL,
  `Address` text DEFAULT NULL,
  `father_name` varchar(100) DEFAULT NULL,
  `mother_name` varchar(100) DEFAULT NULL,
  `Father_Occupation` varchar(100) DEFAULT NULL,
  `Mother_Occupation` varchar(100) DEFAULT NULL,
  `Father_Annual_Income` varchar(20) DEFAULT NULL,
  `Blood_Group` varchar(10) DEFAULT NULL,
  `E_Mail` varchar(100) DEFAULT NULL,
  `PAN_No` varchar(10) DEFAULT NULL,
  `Bank_Name` varchar(100) DEFAULT NULL,
  `Branch` varchar(100) DEFAULT NULL,
  `Account_No` varchar(20) DEFAULT NULL,
  `IFSC_Code` varchar(11) DEFAULT NULL,
  `MICR_Code` varchar(9) DEFAULT NULL,
  `Father_Qualification` varchar(100) DEFAULT NULL,
  `Mother_Qualification` varchar(100) DEFAULT NULL,
  `Identification_Mark1` varchar(100) DEFAULT NULL,
  `Identification_Mark2` varchar(100) DEFAULT NULL,
  `scheme_name` varchar(100) DEFAULT NULL,
  `applicable_income` varchar(20) DEFAULT NULL,
  `applicable_caste` varchar(50) DEFAULT NULL,
  `applicable_gender` varchar(10) DEFAULT NULL,
  `application_date` varchar(20) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `approved`
--

INSERT INTO `approved` (`id`, `register_number`, `Name_of_the_Student`, `Gender`, `date_of_birth`, `Course`, `department`, `Community`, `Religion`, `Contact_No`, `UMIS_NUMBER`, `Aadhar_No`, `Address`, `father_name`, `mother_name`, `Father_Occupation`, `Mother_Occupation`, `Father_Annual_Income`, `Blood_Group`, `E_Mail`, `PAN_No`, `Bank_Name`, `Branch`, `Account_No`, `IFSC_Code`, `MICR_Code`, `Father_Qualification`, `Mother_Qualification`, `Identification_Mark1`, `Identification_Mark2`, `scheme_name`, `applicable_income`, `applicable_caste`, `applicable_gender`, `application_date`, `status`) VALUES
(1, '23PCS248120', 'ISHWARYA E', 'Female', '2002-02-07', 'I M.Sc', 'computer science', 'BC', 'Hindu', '9585958448', '9000083597', '236510665481', '59/37, VAIKKAL PATTARAI, NORTH AMMAPET, ALLIKUTTAI(PO), SALEM-636003', 'M ELANGOVAN', 'E SARATHA', 'WEAVER', 'HOME MAKER', '75000.00', 'B+', 'ishwaryaishu135@gmail.com', 'AOSPI7464N', 'ICICI BANK', 'PATTAKOVIL', '106001002937', 'ICIC0001060', '636229004', '6th', '5th', 'A MOLE ON THE RIGHT HAND ELBOW', 'A SCAR ON THE RIGHT SIDE CHEEK', 'Physically Disabled Student Support', '500000.00', 'All', 'All', '2025-03-16 09:39:30', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rejected`
--

CREATE TABLE `rejected` (
  `id` int(11) NOT NULL,
  `register_number` varchar(50) DEFAULT NULL,
  `Name_of_the_Student` varchar(100) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `date_of_birth` varchar(20) DEFAULT NULL,
  `Course` varchar(100) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `Community` varchar(50) DEFAULT NULL,
  `Religion` varchar(50) DEFAULT NULL,
  `Contact_No` varchar(15) DEFAULT NULL,
  `UMIS_NUMBER` varchar(50) DEFAULT NULL,
  `Aadhar_No` varchar(12) DEFAULT NULL,
  `Address` text DEFAULT NULL,
  `father_name` varchar(100) DEFAULT NULL,
  `mother_name` varchar(100) DEFAULT NULL,
  `Father_Occupation` varchar(100) DEFAULT NULL,
  `Mother_Occupation` varchar(100) DEFAULT NULL,
  `Father_Annual_Income` varchar(20) DEFAULT NULL,
  `Blood_Group` varchar(10) DEFAULT NULL,
  `E_Mail` varchar(100) DEFAULT NULL,
  `PAN_No` varchar(10) DEFAULT NULL,
  `Bank_Name` varchar(100) DEFAULT NULL,
  `Branch` varchar(100) DEFAULT NULL,
  `Account_No` varchar(20) DEFAULT NULL,
  `IFSC_Code` varchar(11) DEFAULT NULL,
  `MICR_Code` varchar(9) DEFAULT NULL,
  `Father_Qualification` varchar(100) DEFAULT NULL,
  `Mother_Qualification` varchar(100) DEFAULT NULL,
  `Identification_Mark1` varchar(100) DEFAULT NULL,
  `Identification_Mark2` varchar(100) DEFAULT NULL,
  `scheme_name` varchar(100) DEFAULT NULL,
  `applicable_income` varchar(20) DEFAULT NULL,
  `applicable_caste` varchar(50) DEFAULT NULL,
  `applicable_gender` varchar(10) DEFAULT NULL,
  `application_date` varchar(20) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rejected`
--

INSERT INTO `rejected` (`id`, `register_number`, `Name_of_the_Student`, `Gender`, `date_of_birth`, `Course`, `department`, `Community`, `Religion`, `Contact_No`, `UMIS_NUMBER`, `Aadhar_No`, `Address`, `father_name`, `mother_name`, `Father_Occupation`, `Mother_Occupation`, `Father_Annual_Income`, `Blood_Group`, `E_Mail`, `PAN_No`, `Bank_Name`, `Branch`, `Account_No`, `IFSC_Code`, `MICR_Code`, `Father_Qualification`, `Mother_Qualification`, `Identification_Mark1`, `Identification_Mark2`, `scheme_name`, `applicable_income`, `applicable_caste`, `applicable_gender`, `application_date`, `status`) VALUES
(1, '23PCS248120', 'ISHWARYA E', 'Female', '2002-02-07', 'I M.Sc', 'computer science', 'BC', 'Hindu', '9585958448', '9000083597', '236510665481', '59/37, VAIKKAL PATTARAI, NORTH AMMAPET, ALLIKUTTAI(PO), SALEM-636003', 'M ELANGOVAN', 'E SARATHA', 'WEAVER', 'HOME MAKER', '75000.00', 'B+', 'ishwaryaishu135@gmail.com', 'AOSPI7464N', 'ICICI BANK', 'PATTAKOVIL', '106001002937', 'ICIC0001060', '636229004', '6th', '5th', 'A MOLE ON THE RIGHT HAND ELBOW', 'A SCAR ON THE RIGHT SIDE CHEEK', 'Women Empowerment Grant', '350000.00', 'All', 'Female', '2025-03-16 09:38:53', 'Rejected'),
(2, '23PCS248118', 'GAYATHRI K', 'Female', '2003-06-30', 'I M.Sc', 'computer science', 'BC', 'Hindu', '9843437715', '9000742489', '473751685011', '318, GANDHI NAGAR, ATTUR(TK), SALEM-636102', 'N KUMAR', 'K RAVI', 'COOLIE', 'HOME MAKER', '60000.00', 'O+', 'kgayathri3062003@gmail.com', NULL, 'UNION BANK OF INDIA', 'ATTUR', '548702010023766', 'UBIN0554871', NULL, '4TH', '5TH', 'A SCAR ON LEFT LEG FINGER', 'A MOLE ON RIGHT HAND WRIST', 'EWS Financial Aid', '150000.00', 'General (EWS)', 'All', '2025-03-12 21:42:55', 'Rejected'),
(3, '23PCS248112', 'ARTHI R', 'Female', '2003-09-11', 'I M.Sc', 'computer science', 'MBC', 'Hindu', '7904048326', '9001934424', '404206194441', '101/69, GUNDOOR, DHARAPURAM(PO), KADYAMPATTI(TK), SALEM-636 309', 'M RAVIKUMAR', 'K KANAGA', 'COOLIE', 'COOLIE', '72000.00', 'O-', 'arthisasi22@gmail.com', 'HIBPR9216K', 'CANARA BANK', 'PERIYAR UNIVERSITY', '110064510468', 'CNRB0008450', '636015024', '5th', '4th', 'A MOLE ON RIGHT SIDE EYE', 'A MOLE ON LEFT SIDE EYE', 'Minority Community Scholarship', '400000.00', 'Muslim, Christian, Sikh, Buddhist, Jain', 'All', '2025-03-16 10:54:28', 'Rejected');

-- --------------------------------------------------------

--
-- Table structure for table `scholarship_applications`
--

CREATE TABLE `scholarship_applications` (
  `id` int(11) NOT NULL,
  `register_number` varchar(50) NOT NULL,
  `Name_of_the_Student` varchar(100) NOT NULL,
  `scheme_id` int(11) NOT NULL,
  `scheme_name` varchar(100) NOT NULL,
  `application_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `scholarship_applications`
--

INSERT INTO `scholarship_applications` (`id`, `register_number`, `Name_of_the_Student`, `scheme_id`, `scheme_name`, `application_date`) VALUES
(11, '23PCS248118', 'GAYATHRI K', 6, 'Women Empowerment Grant', '2025-03-16 05:03:17'),
(12, '23PCS248118', 'GAYATHRI K', 6, 'Women Empowerment Grant', '2025-03-16 05:03:24');

-- --------------------------------------------------------

--
-- Table structure for table `scholarship_schemes`
--

CREATE TABLE `scholarship_schemes` (
  `id` int(11) NOT NULL,
  `scheme_name` varchar(255) NOT NULL,
  `applicable_income` decimal(10,2) NOT NULL,
  `applicable_caste` varchar(100) NOT NULL,
  `applicable_gender` enum('Male','Female','Other','All') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `scholarship_schemes`
--

INSERT INTO `scholarship_schemes` (`id`, `scheme_name`, `applicable_income`, `applicable_caste`, `applicable_gender`) VALUES
(3, 'OBC Educational Assistance', 300000.00, 'OBC', 'Female'),
(4, 'Minority Community Scholarship', 400000.00, 'Muslim, Christian, Sikh, Buddhist, Jain', 'All'),
(5, 'EWS Financial Aid', 150000.00, 'General (EWS)', 'All'),
(6, 'Women Empowerment Grant', 350000.00, 'All', 'Female'),
(7, 'Physically Disabled Student Support', 500000.00, 'All', 'All'),
(8, 'new welfare schemes', 20000.00, 'obc', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `Course` varchar(50) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `register_number` varchar(20) NOT NULL,
  `Name_of_the_Student` varchar(100) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `Community` varchar(50) DEFAULT NULL,
  `Religion` varchar(50) DEFAULT NULL,
  `father_name` varchar(100) DEFAULT NULL,
  `mother_name` varchar(100) DEFAULT NULL,
  `Address` text DEFAULT NULL,
  `Blood_Group` varchar(10) DEFAULT NULL,
  `Contact_No` varchar(15) DEFAULT NULL,
  `E_Mail` varchar(100) DEFAULT NULL,
  `Aadhar_No` varchar(12) DEFAULT NULL,
  `PAN_No` varchar(10) DEFAULT NULL,
  `Bank_Name` varchar(100) DEFAULT NULL,
  `Branch` varchar(100) DEFAULT NULL,
  `Account_No` varchar(20) DEFAULT NULL,
  `IFSC_Code` varchar(11) DEFAULT NULL,
  `MICR_Code` varchar(9) DEFAULT NULL,
  `Father_Qualification` varchar(50) DEFAULT NULL,
  `Father_Occupation` varchar(50) DEFAULT NULL,
  `Father_Annual_Income` decimal(15,2) DEFAULT NULL,
  `Mother_Qualification` varchar(50) DEFAULT NULL,
  `Mother_Occupation` varchar(50) DEFAULT NULL,
  `UMIS_NUMBER` varchar(20) DEFAULT NULL,
  `Identification_Mark1` varchar(100) DEFAULT NULL,
  `Identification_Mark2` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`Course`, `department`, `register_number`, `Name_of_the_Student`, `date_of_birth`, `Gender`, `Community`, `Religion`, `father_name`, `mother_name`, `Address`, `Blood_Group`, `Contact_No`, `E_Mail`, `Aadhar_No`, `PAN_No`, `Bank_Name`, `Branch`, `Account_No`, `IFSC_Code`, `MICR_Code`, `Father_Qualification`, `Father_Occupation`, `Father_Annual_Income`, `Mother_Qualification`, `Mother_Occupation`, `UMIS_NUMBER`, `Identification_Mark1`, `Identification_Mark2`) VALUES
('I M.Sc', 'computer science', '23PCS248101', 'ANSAR A', '2002-11-22', 'Male', 'BCM', 'Hindu', ' AFSAR as', 'S NAJEEBA', '7, 5TH Cross, JKR Garden, Mahalakshmi Nagar, Kannankurichi, Salem-636 008', 'B+', '8903594058', 'ansarafsar001@gmail.com', '836129232859', 'IDDPM1824K', 'SBI', 'CHERRY ROAD, SALEM', '', '', '', '9th', 'DAILY WAGES', 72000.00, '12th', 'HOME MAKER', '9001668280', 'A MOLE ON THE FOREHEAD', 'mole'),
('I M.Sc', 'computer science', '23PCS248102', 'HARIHARAN E', '2003-01-18', 'Male', 'SC', 'Hindu', 'ELAYARAJA', 'VIJAYA', '286, BURN AND COMPANY, MAGANASITE MINES (PO), NEAR VINAYAGAR KOVIL , SALEM-636302', 'B+', '8870014588', 'hariharan1812k3e@gmail.com', '594701798772', 'IDDPM1824N', 'IOB', 'JAGIR AMMAPALAYAM', '352801000007883', 'IOBA0003528', '636020050', '12th', 'Driver', 80000.00, '8th', 'HOME MAKER', '9001629368', 'A MOLE ON THE RIGHT HAND INDEX FINGER', 'A MOLE ON THE NOISE'),
('I M.Sc', 'computer science', '23PCS248103', 'LOGANATHAN M', '2004-01-29', 'Male', 'BC', 'Hindu', 'MOORTHI', 'GEETHA', '15A, STATE BANK COLONY, FIRST ST, AMMAPET, SALEM-636 003', 'A+', '9025475968', 'loganathanbcashift2@gmail.com', '763537792960', 'IDDPM1824A', 'SBI', 'AMMAPET', '35898569746', 'SBIN0012772', '636002108', '10th', 'DAILY WAGES', 72000.00, '4th', 'HOME MAKER', '9001625804', 'A SCAR ON THE LEFT LEG', 'A MOLE ON THE RIGHT HAND'),
('I M.Sc', 'computer science', '23PCS248104', 'MEGANATHAN M', '2002-03-25', 'Male', 'MBC', 'Hindu', 'C MANICKAM', 'M DHANALAKSHMI', '5-107/4-277, MUTHUNAICKENPATTI, MALLAGOUNDANUR, KALIYAMMAN KOVIL, OMALUR(TK),SALEM-636 304', 'B+', '8056858406', 'meganathan25302@gmail.com', '575533221178', 'IVXPM8187C', 'IOB', 'KARUPPUR', '277101000009154', 'IOBA0002771', '636020038', '-', 'DAILY WAGES', 96000.00, '5th', 'Daily Wages', '9001934781', 'A MOLE ON THE RIGHT AARM', 'A MOLE ON THE LEFT ARM'),
('I M.Sc', 'computer science', '23PCS248105', 'MUTHUSAMY V', '2003-01-11', 'Male', 'SC(A)', 'Hindu', 'M VEERASAMY', 'V SUDAMANI', 'ARUNTHATHIYAR ST, THATHAMPATTY(PO), GANGAVALLI(TK), SALEM-636113', 'B+', '9344986993', 'muthuveera6993@gmail.com', '838901978267', 'IPVPM3738B', 'INDIAN BANK', 'THAMMAMPATTI', '7590426240', 'IDIB0007013', '636019081', '5TH', 'COOLIE', 60000.00, '5TH', 'HOME MAKER', '9000775186', 'A BLACK MOLE ON THE LEFT HAND LITTLE FINGER', 'A MOLE BELOW RIGHT SIDE OF THE NECK'),
('I M.Sc', 'computer science', '23PCS248106', 'RANJITHKUMAR V V', '2003-06-10', 'Male', 'BC', 'Hindu', 'VASUDEVAN', 'VENNILA', '495, MARAVANATHAM, KATTUKOTTAI, KUNNUMALAI, VP(AGRAM)(PS), KALLAKURICHI DT, CHINNASALEM-606201', 'O-', '8807631598', 'ranjithvasu244@gmail.com', '766259595240', 'FSLPR8756Q', 'IOB', 'CHINNASALEM', '011901000039645', 'IOBA0000119', '606020104', '9TH', 'FARMAR', 78000.00, '10TH', 'HOME MAKER', '9001952230', 'A MOLE ON THE RIGHT HAND', 'A MOLE IN LEFT HAND'),
('I M.Sc', 'computer science', '23PCS248107', 'SARGURU I', '2002-12-31', 'Male', 'BC', 'Hindu', 'K INDRAKUMAR', 'I SARASWATHI', '1/96A, VAIKADU VAIKAL PATTARAI, TADAMPATTI, SALEM-636014', 'A+', '6379032189', 'sargurui66murugan@gmail.com', '706482827337', 'AQEP19244C', 'INDIAN OVERSEAS BANK', NULL, '278301000014576', 'IOBA0002783', '636020029', '5TH', 'WEAVER', 72000.00, 'NO', 'WEAVER', '9001953099', 'A MOLE ON THE RIGHT EYEBROW', 'A MOLE ON THE BACK OF THE LEFT ANKLE'),
('I M.Sc', 'computer science', '23PCS248108', 'SIVAKUMAR M', '2003-06-20', 'Male', 'MBC', 'Hindu', 'MANICKAM C', 'M DHANALAKSHMI', '5-107/4-277, MALLAGOUNDANUR, CHELLAPILLAIKUTTAI(PO), OMALUR, SALEM-636304', 'B+', '9361729049', 'sm4055107@gmail.com', '618966826635', 'QLTPS5401K', 'IOB', 'KARUPPUR', '277101000009153', 'IOBA0002771', '636020038', '-', 'DAILY WAGES', 96000.00, '-', 'Daily Wages', '9002100617', 'A MOLE ON THE RIGHT EYEBROW', 'A SCAR ON THE RIGHT ARM'),
('I M.Sc', 'computer science', '23PCS248109', 'VENKATESH A', '2002-06-17', 'Male', 'SC', 'Hindu', 'ANBAZHAGAN', 'BABY', '2/181, NORTH ST, VASANTHKRISHNAPURAM, VILLUPURAM-605758', 'AB+', '9626973857', 'venkateshvenkatesha430@gmail.com', '855937609645', 'DXCPA2280L', 'STATE BANK', 'TIRUKKOYILUR', '37090353241', 'SBIN0000992', '605002053', '12TH', 'EXSERVICE MAN', 153924.00, '10TH', 'HOME MAKER', '9001745621', 'A SCAR ON THE RIGHT LEG', 'A MOLE ON THE RIGHT HAND'),
('I M.Sc', 'computer science', '23PCS248110', 'VIJAYKRISHNA  P V', '2002-08-31', 'Male', 'BC', 'Hindu', 'P R VENKATESAN', 'V JAMUNA', '44/9, BABU NAGAR, SALEM-1', 'B+', '8610675040', 'krisvijay3108@gmail.com', '766983036229', NULL, 'CENTRAL BANK OF INDIA', 'SALEM', '3541399700', 'CBIN0280903', '636016002', '10TH', NULL, 70000.00, '10TH', 'HOME MAKER', '9001975729', 'A MOLE ON THE RIGHT SIDE OF THE CHEST', 'A SCAR ON THE LEFT SIDE OF THE FOREHEAD'),
('I M.Sc', 'computer science', '23PCS248111', 'ANU S', '2003-11-14', 'Female', 'SC', 'Hindu', 'K SELVARAJ', 'S MALLIKA', '517, SOUTH ST, PERUVANGUR, THANDALAI(PO), KALLAKURICHI-606213', 'B+', '6369648859', 'anusm1411@gmail.com', '812019397136', NULL, 'INDIAN BANK', 'DEVAPANDALAM', '7269707105', 'IDIB000D075', '606019206', NULL, 'DAILY WAGES', 78000.00, NULL, 'Daily Wages', '9001633941', 'A MOLE ON RIGHT NECK', 'SCAR ON FOREHEAD'),
('I M.Sc', 'computer science', '23PCS248112', 'ARTHI R', '2003-09-11', 'Female', 'MBC', 'Hindu', 'M RAVIKUMAR', 'K KANAGA', '101/69, GUNDOOR, DHARAPURAM(PO), KADYAMPATTI(TK), SALEM-636 309', 'O-', '7904048326', 'arthisasi22@gmail.com', '404206194441', 'HIBPR9216K', 'CANARA BANK', 'PERIYAR UNIVERSITY', '110064510468', 'CNRB0008450', '636015024', '5th', 'COOLIE', 72000.00, '4th', 'COOLIE', '9001934424', 'A MOLE ON RIGHT SIDE EYE', 'A MOLE ON LEFT SIDE EYE'),
('I M.Sc', 'computer science', '23PCS248113', 'BAVITHRA J', '2001-12-18', 'Female', 'BC', 'Hindu', 'S JOTHIBOSS', 'P KIRUTHIGA DEVI', '112/A, KAMBAPERUMAL KOVIL ST, ATTUR(TK), SALEM-636 102', 'B+', '6385518732', 'bavithrajocs2001@gmail.com', '333200898368', 'CDZPJ0478F', 'INDIAN', 'ATTUR', '6350986827', 'IDIB000A033', '636019088', '12th', 'farmer', 20000.00, 'nill', 'former', '9001973556', 'A MOLE ON THE LEFT HAND', 'A MOLE ON THE LEFT LEG'),
('I M.Sc', 'computer science', '23PCS248114', 'DHARANI K', '2000-12-21', 'Female', 'MBC', 'Hindu', 'A KARUPPAIYA', 'K RAJESWARI', '1/204, CHINNAPUSALIYUR, MARA MANGALATHUPATTI, MOHAN NAGAR(PO), SALEM-636 030', 'A+', '8428530457', 'dharan9k2112@gmail.com', '731529235628', NULL, 'UNION', 'SARKAR GOLAPATTI', '769602010003778', 'UBIN0576964', '636026013', 'NO', 'MANSON', 50000.00, '8th', 'HOME MAKER', '9001933318', 'A MOLE ON THE RIGHT HAND', 'A SCAR ON THE RIGHT HAND'),
('I M.Sc', 'computer science', '23PCS248115', 'DHARSHINIPRIYA J J', '2003-03-21', 'Female', 'BC', 'Hindu', 'S JAYARAMAN', 'S JOTHI', '1/101, OLD ST, VEMBADITHALAM, SALEM', 'B+', '9629750223', 'sjdharshinipriyapriya@gmail.com', '626479563620', 'HSSPD6602L', 'SBI', 'ILAMBILLAI', '41116432196', 'SBIN0015036', '636002122', '10TH', 'BUS DRIVER', 96000.00, '10TH', 'HOME MAKER', '9000091159', 'A MOLE ON RIGHT SIDE FOREHEAD', 'A SCAR ON NEAR LEFT ELBOW'),
('I M.Sc', 'computer science', '23PCS248116', 'ELAKKIYA M', '2002-06-23', 'Female', 'BC', 'Hindu', 'A MURUGESAN', 'M RADHA', '1/75, KATTAMPATTI, THARAMANGALAM(po), METTUR(TK), SALEM-636 501', 'B+', '8825594522', 'elakkiya2022@gmail.com', '741396014174', 'AGRPE6829J', NULL, NULL, '0336309000008074', 'dbssoi0336', '636641011', '12th', 'EB', 300000.00, '6TH', 'HOME MAKER', '9001974301', 'A MOLE JUST BELOW OF RIGHT EYE', 'A SCAR ON RIGHT HEEL'),
('I M.Sc', 'computer science', '23PCS248117', 'GAYATHRI DEVI S', '2003-05-06', 'Female', 'BC', 'Hindu', 'A SAMBATH', 'S RAJESWARI', '3/129, GANDHIPURAM(VILL), DHASARAHALLI(PO), HA', 'A+', '9345816799', 'gayugayu6503@gmail.com', '655303873191', 'DOLPG1816J', 'INDIAN BANK', 'Morappur', '7044156537', 'IDIB000M041', '636019111', '10TH', 'LABOUR', 60000.00, '10TH', 'FARMER', '9001975317', 'A MOLE ON THE RIGHT HAND', 'A MOLE ON THE LEFT HAND'),
('I M.Sc', 'computer science', '23PCS248118', 'GAYATHRI K', '2003-06-30', 'Female', 'BC', 'Hindu', 'N KUMAR', 'K RAVI', '318, GANDHI NAGAR, ATTUR(TK), SALEM-636102', 'O+', '9843437715', 'kgayathri3062003@gmail.com', '473751685011', NULL, 'UNION BANK OF INDIA', 'ATTUR', '548702010023766', 'UBIN0554871', NULL, '4TH', 'COOLIE', 60000.00, '5TH', 'HOME MAKER', '9000742489', 'A SCAR ON LEFT LEG FINGER', 'A MOLE ON RIGHT HAND WRIST'),
('I M.Sc', 'computer science', '23PCS248119', 'GEETHA V', '2003-05-22', 'Female', 'MBC', 'Hindu', 'K VENKATESAN', 'V SARASWATHI', 'E-13, THAMMANNAN ROAD, THALA GOUNDER KADU, ARISIPALAYAM, SALEM-636009', 'O+', '8778665639', 'venkatgeetha165@gmail.com', '202767467357', 'EKDPG1779M', 'INDIAN BANK', '4 ROADS', '6122314212', 'IDIB000N064', '636019007', 'NO', 'COOLIE', 72000.00, 'NO', 'COOLIE', '9001618131', 'A BLACK MOLE INDEX FINGER OF RIGHT HAND', 'A BLACK MOLE ON BACK NECK'),
('I M.Sc', 'computer science', '23PCS248120', 'ISHWARYA E', '2002-02-07', 'Female', 'BC', 'Hindu', 'M ELANGOVAN', 'E SARATHA', '59/37, VAIKKAL PATTARAI, NORTH AMMAPET, ALLIKUTTAI(PO), SALEM-636003', 'B+', '9585958448', 'ishwaryaishu135@gmail.com', '236510665481', 'AOSPI7464N', 'ICICI BANK', 'PATTAKOVIL', '106001002937', 'ICIC0001060', '636229004', '6th', 'WEAVER', 75000.00, '5th', 'HOME MAKER', '9000083597', 'A MOLE ON THE RIGHT HAND ELBOW', 'A SCAR ON THE RIGHT SIDE CHEEK'),
('I M.Sc', 'computer science', '23PCS248121', 'JANANI K', '2003-06-24', 'Female', 'SC', 'Hindu', 'V KALIYA MOORTHI', 'K VALARMATHI', '501, EAST ST, PALAIYAM ROAD, PERVANGNUR, THANDALAI(PO), KALLAKURICHI', 'O+', '9629607758', 'kvjananios@gmail.com', '585182721915', 'MJMPK8927R', 'indian bank', 'SALEM', '7270477198', 'IDIB0005006', '636019003', '8TH', 'DAILY WAGES', 68000.00, '8TH', 'Daily Wages', '9001624049', 'A MOLE NEAR THE FOREHEAD', 'A MOLE ON THE RIGHT HAND'),
('I M.Sc', 'computer science', '23PCS248122', 'KAVIYA A', '2002-11-23', 'Female', 'BC', 'Hindu', 'P ANNADURAI', 'A GUNA', '216/B, VMR THEATER BACKSIDE, SAMINATHAPURAM, SALEM-636009', 'A+', '9842952144', 'kaviyadurai4@gmail.com', '368846583043', 'MSUPK9860R', 'karnadaka', 'FAIRLANDS', '7302500102081301', 'KARB0000730', '636052003', '10TH', 'Driver', 96000.00, '12th', 'HOME MAKER', '9001953800', 'A SCAR ON THE CHIN', 'A MOLE ON THE NECK'),
('I M.Sc', 'computer science', '23PCS248123', 'MANIMEKALAI G', '2004-04-29', 'Female', 'MBC', 'Hindu', 'T GANAPATHY', 'G RATHIKA', '110/64, NALLAGOUNDAMPATTI, OMALUR(TK), SALEM', 'O+', '8807997544', 'mekalaiganapathy36@gmail.com', '976559115164', 'GVVPM1628G', 'SBI', 'OMALUR', '33902382479', 'SBIN0001030', '636002009', '12TH', 'POWER LOOM', 72000.00, '4TH', 'HOME MAKER', '9001628786', 'A SCAR ON THE RIGHT CHECK', 'A MOLE ON THE BACK OF THE NECK'),
('I M.Sc', 'computer science', '23PCS248124', 'NARMATHA K', '2003-01-23', 'Female', 'BC', 'Hindu', 'K S KANDHASAMY', 'K MENAKA', '1-79C, Kattampatti, Mettukkadu, Thormangalam(PO)Mettur(TK), Jalakandapuram, Salem-636501', 'O+', '9788309982', 'narmathanarmatha2338@gmail.com', '336129629050', 'CNTPN8193F', 'SBI', 'Jalakandapuram', '42294259466', 'SBIN0005381', '636002035', '5TH', 'Driver', 80000.00, '7TH', 'HOME MAKER', '9001953588', 'A BLACK MOLE ON THE RIGHT SHOULDER', 'A SCAR ON THE LEFT ARM'),
('I M.Sc', 'computer science', '23PCS248125', 'NESIKA S M', '2003-01-18', 'Female', 'BC', 'Hindu', 'S MADURAIPILLAI', 'M SHANTHI', '447, B.No.7, Managar Ammal Eari St, Salem-636006', 'B+', '9965640786', 'nesikasm@gmail.com', '216800317442', 'CRMPN0303E', 'SBI', 'Dadagapatti', '35164572289', 'SBIN0007200', '636002004', '12TH', 'COOLIE', 72000.00, '9TH', 'HOME MAKER', '9000123809', 'A MOLE ON THE RIGHT HAND', 'A MOLE ON THE LEFT ELBOW'),
('I M.Sc', 'computer science', '23PCS248126', 'PAVITHRA B', '2002-07-11', 'Female', 'SC', 'Hindu', 'L BAKIYARAJ', 'B KOLONJI', '443, East St, Thandalai(PO), Kallakurichi(TK), Perruvangur-606 213', 'B+', '7339488946', 'pavithrabakiyaj@gmail.com', NULL, NULL, 'INDIAN', 'DEVAPANDALAM', '7269706123', 'IDIB0000075', '606019206', NULL, 'DAILY WAGES', 84000.00, NULL, NULL, '9000145430', 'A SCAR NEAR RIGHT EYE', 'A MOLE BETWEEN MOUTH AND NOSE'),
('I M.Sc', 'computer science', '23PCS248127', 'RAJESWARI M', '2003-07-15', 'Female', 'SC(A)', 'Hindu', 'MARUTHAMUTHU K', 'JAYA M', '80, Thathathiripuram, North St, Chinnsalem(TK), Kallakurichi-606301', 'B-', '9940356247', 'mrajeswari1507@gmail.com', '933686965613', 'GAMPR4066R', 'INDIAN', 'CHINNASALEM', '9940356247', 'IDIB000C045', '606019004', '9TH', 'FARMAR', 70000.00, '6TH', 'HOME MAKER', '9001931811', 'A MOLE UPPER THE RIGHT EYEBROW', 'A SCAR ON THE LEFT FEET'),
('I M.Sc', 'computer science', '23PCS248128', 'RINOSHA FATHIMA J', '1999-03-19', 'Female', 'BCM', 'Hindu', 'M JAMAL NASAR', 'J SAMEENA BEGAM', '37/13C/2D, Pillayar Nagar, 3rd Cross, Court Road, Hasthampaty, Salem-636007', 'O+', '8825785903', 'rinoshafathimaj@gmail.com', '787098226567', 'E11PR7792Q', 'BANK OFBARODA', 'ARAVAKURICHI', '5420100011614', 'BRABOARAVAK', '639012003', '10TH', 'MANAGER', 120000.00, '8TH', 'HOME MAKER', '9001951776', 'A MOLE AT THE RIGHT HAND', 'A MOLE AT THE RIGHT CHEEK'),
('I M.Sc', 'computer science', '23PCS248129', 'SARATHI S', '2003-06-02', 'Female', 'MBC', 'Hindu', 'P SEENIVASAN', 'S SELVAMANI', '4/401, Poyyanur, Kuppampatti, Mettur(TK), Salem', 'B+', '9524484533', 'sarathiseeni2003@gmail.com', '358861589828', 'QETPS7052P', 'INDIAN', 'OMALUR', '7263665535', 'IDIB0000008', '636019015', '8TH', 'WEAVER', 84000.00, '2ND', 'HOME MAKER', '9001952645', 'A BLACK MOLE ON NEAR ON THE CHIN', 'A BLACK MOLE ON RIGHT CHEEK'),
('I M.Sc', 'computer science', '23PCS248130', 'SEMMALAR T', '2002-09-05', 'Female', 'MBC', 'Hindu', 'L THANGAMANI', 'T KAMALA', '542, Siva Sakthi Nagar, Seelanaikenpatti, Salem-636201', 'O+', '8610603636', 'semmalar8610@gmail.com', '843127085692', NULL, 'SBI', 'Dadagapatti', '31632913069', 'SBIN0007200', '636002004', '8TH', 'COOLIE', 60000.00, 'NO', 'HOME MAKER', '9002220243', 'A MOLE ON THE LOWER HAND', 'A MOLE ON THE MIDDLE FINGER'),
('I M.Sc', 'computer science', '23PCS248131', 'SOWJANYA S', '2003-01-10', 'Female', 'MBC', 'Hindu', 'S SARAVANAN', 'S KANAMMAL', '16/1, CHEKARA ST, KUMARASAMYPATTI, SALEM-7', 'AB+', '8190801412', 'sowjikannammal@gmail.com', '476714975269', 'QADPS7203C', 'CANARA BANK', 'ALAGAPURAM', '1225108053469', 'CNRB0001225', '636015003', 'NO', 'COOLIE', 72000.00, 'NO', 'HOME MAKER', '9001934148', 'A MOLE ON THE NECK', 'A MOLE ABOVE THE RIGHT EYEBROW'),
('I M.Sc', 'computer science', '23PCS248132', 'SREEMATHI S', '2003-06-25', 'Female', 'BC', 'Hindu', 'N SETHURAMAN', 'S VASUKI', '65/245, THAMMANNAN ROAD, ARISIPALAYAM, SALEM-9', 'A+', '8122200433', 'sreemathi2563@gmail.com', '602775114795', 'RRTPS5316E', 'indian bank', '4 ROADS', '6121576744', 'IDIB000N064', '636019007', '12TH', 'BUSINESS', 72000.00, '6TH', 'HOME MAKER', '9001631911', 'A BLACK MOLE ON NEAR THE CHIN', 'A BLACK MOLE ON NEAR THE RIGHT EYE'),
('I M.Sc', 'computer science', '23PCS248133', 'SUGANYA G', '2003-03-29', 'Female', 'BC', 'Hindu', 'GANESH R', 'SANGEETHA G', '20/37-A, NADHI MULLAH MAKKAN ST, AMMAPET, SALEM-1', 'O+', '9486475169', 'suganyasugi419@gmail.com', '964032629228', 'OPWPS51234', 'UNION BANK OF INDIA', 'SALEM TOWN', '002922010000358', 'UBIN0900290', '636026023', '6th', 'TEA MASTER', 72000.00, '10TH', 'HOME MAKER', '9001531005', 'A MOLE ON THE POINTING LITTLE FINGER OF THE RIGHT HAND', 'A MOLE ON THE POINTING FINGER OF THE LEFT HAND'),
('I M.Sc', 'computer science', '23PCS248134', 'VAISHNAVI M', '2003-09-18', 'Female', 'MBC', 'Hindu', 'R MATHIYAZHAGAN', 'M KARTHIKA', '2/22-1, CHINNA SATHAPPADI, METTUR, SALEM-636451', 'A+', '9342257770', 'vaishunila1212@gmail.com', '297410312064', 'HKFPM5224L', 'indian bank', 'MECHERI', '7203589379', 'IDIB000M025', '636019018', '5TH', 'Driver', 84000.00, '10TH', NULL, '9000104283', 'A MOLE IN RIGHT SIDE NECK', 'A MOLE IN RIGHT NEAR EAR'),
('I M.Sc', 'computer science', '23PCS248135', 'VISHNUVARDHINI C', '2001-04-26', 'Female', 'SC', 'Hindu', 'M CHANDRA SEKARAN', 'M SUGANYA', '3/56, AMBEDKAR NAGAR, BELUKURICHI, SENDAMANGALAM(TK), NAMAKKAL-637402', 'AB+', '9578079710', 'muthu.kanaga.2708@gmail.com', '830300493125', 'CSTPV9818E', 'TAMILNADU GRAMA BANK', 'BELUKURICHI', '10123357130', 'IDIB0PLB001', '636423002', 'NO', '-', 72000.00, 'BE', 'DATA ENTRY', '9001974985', 'A MOLE ON THE RIGHT HAND ARM', 'A MOLE ON THE NECK BACK SIDE'),
('I M.Sc', 'computer science', '23PCS248136', 'YOGADHARINI V', '2003-01-01', 'Female', 'BC', 'Hindu', 'P VAIRAVEL', 'V SATHYA', '207, BHARATHIYAR ST, RAMANATHAPURAM, AMMAPET, SALEM-636003', 'B+', '7010368361', 'yogamuthu35@gmail.com', '878569344432', 'IYE2326130', 'STATE BANK', 'AMMAPET', '33851662439', 'SBIN0012772', '636002108', '12TH', 'POWER LOOM', 72000.00, '10TH', 'HOME MAKER', NULL, 'A MOLE NEAR THE LIP', 'A MOLE NEAR THE WRIST');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `register_number` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` enum('admin','student') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `register_number`, `email`, `phone_number`, `password`, `user_type`) VALUES
(5, 'Admin User', 'admin123', '', 'admin@example.com', '9876543210', '$2y$10$p8f0fbPc3XWBgrUZphFwiOOewsKCs1mRPNbvtMS2oKPU0iIujinlC', 'admin'),
(6, 'Student User', 'student123', '23PCS248118', 'student@example.com', '9876543211', '$2y$10$0nyyakLmE5EBorcRn1XTc.bu/11TWIz9aqt27svc.FbvnWYrn.3Lq', 'student'),
(7, 'HARIHARAN E', 'hari123', '23PCS248108', 'hari@gmail.com', '9944557788', '$2y$10$ig5Wkue1R/PAekOg8/wRp.yFM80ddZKNAYEt9VTBzj8TQIxB2H6M2', 'student'),
(8, 'EKALLIYA', 'ELAKKIYA45', '', 'ELAKKIYA@GMAIL.COM', '6379648633', '$2y$10$LEkVU9YdOAxvfj0G0MvbVuzRdt1U1xDpBzNfTc9cjBVT8.W0oYo02', 'admin'),
(9, 'Arthi', 'arthi123', '23PCS248112', 'arthi@gmail.com', '9988775568', '$2y$10$TMhamZWgNt2s.gcJiRXHDueit96G/CBbQxv2/nhUwORc0KwGzhHwa', 'student'),
(10, 'ELAKKIYA', 'ELAKKI', '23PCS248116', 'elakkiya2022@gmail.com', '8825594522', '$2y$10$LfRx6kvoBkiiHfmfYfczUe12K5WJf6h5HEh66k5Q6y/CHe6csPfq.', 'student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `approved`
--
ALTER TABLE `approved`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `rejected`
--
ALTER TABLE `rejected`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `scholarship_applications`
--
ALTER TABLE `scholarship_applications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `scheme_id` (`scheme_id`);

--
-- Indexes for table `scholarship_schemes`
--
ALTER TABLE `scholarship_schemes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`register_number`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `approved`
--
ALTER TABLE `approved`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `rejected`
--
ALTER TABLE `rejected`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `scholarship_applications`
--
ALTER TABLE `scholarship_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `scholarship_schemes`
--
ALTER TABLE `scholarship_schemes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD CONSTRAINT `password_resets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `scholarship_applications`
--
ALTER TABLE `scholarship_applications`
  ADD CONSTRAINT `scholarship_applications_ibfk_1` FOREIGN KEY (`scheme_id`) REFERENCES `scholarship_schemes` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
